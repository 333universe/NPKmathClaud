"""
NKP v3: a knowledge-acquisition engine for AI agents.

An LLM's weights don't change mid-conversation, so learning has to live in an
external layer. This module is that layer: it does the bookkeeping models are
bad at -- calibrated belief, provenance, contradiction, staleness, and spending
effort only where it pays.

Loop
  INGEST   claim (subject, predicate, object) arrives from a source
  MEASURE  surprisal in bits under current belief (new slot ~10 bits, confirm ~0,
           challenge to a strong belief ~14)
  TRIAGE   adaptive horizon: surprising claims EXPAND (auto-queued for
           verification); expected ones COMPRESS (absorbed silently)
  BELIEVE  log-odds evidence per (slot, object), one vote per independent ORIGIN
           (echoes of the same origin don't count twice); optional time decay
  DECIDE   belief() -> ANSWER | HEDGE | ACQUIRE   (what the agent should do now)
  PLAN     plan(budget) -> which questions to ask which sources, ranked by
           value = importance * uncertainty * (2*reliability-1) / cost

Extraction (text -> claims) and retrieval (asking a source) are the caller's job:
plug in an LLM/search tool on each side. Standard library only.

    python nkp_acquire.py          demo
    python nkp_acquire.py --test   self-tests
"""
from __future__ import annotations

import json
import math
import sys
import time
from dataclasses import dataclass
from typing import Callable, Dict, List, Optional, Tuple


def _n(x) -> str:
    return " ".join(str(x).lower().split())


@dataclass(frozen=True)
class Claim:
    subject: str
    predicate: str
    obj: str


@dataclass
class Source:
    name: str
    reliability: float                     # P(source is right), in (0.5, 1)
    cost: float = 1.0                      # any consistent unit: tokens, seconds, $
    covers: Optional[frozenset] = None     # predicates it can answer; None = all
    repeatable: bool = False               # True for e.g. web search: asking again yields new origins


@dataclass
class Belief:
    slot: tuple
    best: Optional[str]
    confidence: float                      # P(best is right); 0 if nothing known
    status: str                            # UNKNOWN | TENTATIVE | ESTABLISHED | CONTESTED
    alternatives: List[Tuple[str, float]]
    advice: str                            # ANSWER | HEDGE | ACQUIRE


@dataclass
class Ingested:
    kind: str          # NEW | CONFIRMS | CONFLICTS | DUPLICATE
    action: str        # ABSORB (warm-up) | EXPAND | COMPRESS | SKIP
    surprisal: float   # bits
    confidence_before: float
    confidence_after: float


@dataclass
class Acquisition:
    subject: str
    predicate: str
    source: str
    voi: float
    cost: float


class Horizon:
    """Adaptive surprise threshold: EMA mean + k * EMA std (habituation)."""

    def __init__(self, k=1.5, ema=0.15, min_std=0.75):
        self.k, self.ema, self.min_std = k, ema, min_std
        self.mean = self.var = 0.0
        self.n = 0

    def value(self) -> Optional[float]:
        return None if self.n == 0 else self.mean + self.k * max(math.sqrt(self.var), self.min_std)

    def update(self, x: float) -> None:
        if self.n == 0:
            self.mean = x
        else:
            d = x - self.mean
            self.mean += self.ema * d
            self.var = (1 - self.ema) * (self.var + self.ema * d * d)
        self.n += 1


class NKPEngine:
    def __init__(self, clock: Callable[[], float] = time.time, open_n: int = 1000,
                 warmup: int = 3, auto_importance: float = 0.5):
        self.clock = clock
        self.open_n = open_n                  # prior guess at how many answers a slot could have
        self.warmup = warmup
        self.auto_importance = auto_importance
        self.sources: Dict[str, Source] = {}
        self.ev: Dict[tuple, Dict[str, Dict[str, Tuple[str, float]]]] = {}  # slot->obj->origin->(source,t)
        self.importance: Dict[tuple, float] = {}
        self.half_life: Dict[str, float] = {}
        self.multi: set = set()
        self.horizon = Horizon()
        self.n = 0

    # ---- configuration ---------------------------------------------------
    def register_source(self, name, reliability, cost=1.0, covers=None, repeatable=False) -> Source:
        s = Source(_n(name), float(reliability), float(cost),
                   frozenset(map(_n, covers)) if covers else None, repeatable)
        self.sources[s.name] = s
        return s

    def set_half_life(self, predicate: str, half_life: float) -> None:
        """Volatile facts (versions, prices, office-holders): evidence fades."""
        self.half_life[_n(predicate)] = float(half_life)

    def mark_multi_valued(self, predicate: str) -> None:
        """Predicates that can hold many objects at once never conflict."""
        self.multi.add(_n(predicate))

    def want(self, subject, predicate, importance=1.0, obj=None) -> None:
        self.importance[self._slot(_n(subject), _n(predicate), None if obj is None else _n(obj))] = importance

    # ---- belief ----------------------------------------------------------
    def _slot(self, s, p, o=None) -> tuple:
        return (s, p, o) if p in self.multi and o is not None else (s, p)

    def _dist(self, slot, now) -> Tuple[Dict[str, float], float]:
        """P(object) per candidate plus P(unknown). Evidence odds multiply across
        independent origins; evidence for volatile predicates fades with age and the
        faded share returns to 'unknown' (so a fully stale fact reads as unknown, not 50/50)."""
        hl = self.half_life.get(slot[1])
        raw = {}
        for obj, origins in self.ev.get(slot, {}).items():
            score = wsum = dsum = 0.0
            for src_name, t in origins.values():
                r = min(max(self.sources[src_name].reliability, 0.501), 0.999)
                w = math.log(r / (1 - r))
                d = 0.5 ** (max(0.0, now - t) / hl) if hl else 1.0
                score += w
                wsum += w
                dsum += w * d
            raw[obj] = (math.exp(score), dsum / wsum)         # (odds, freshness in [0,1])
        z = 1.0 + sum(o for o, _ in raw.values())             # the "1" is prior mass on "something else"
        dist = {obj: fresh * odds / z for obj, (odds, fresh) in raw.items()}
        return dist, 1.0 - sum(dist.values())

    def _belief(self, slot, now) -> Belief:
        dist, _ = self._dist(slot, now)
        ranked = sorted(dist.items(), key=lambda kv: (-kv[1], kv[0]))
        if not ranked:
            return Belief(slot, None, 0.0, "UNKNOWN", [], "ACQUIRE")
        best, pb = ranked[0]
        second = ranked[1][1] if len(ranked) > 1 else 0.0
        if second >= 0.5 * pb:
            status, advice = "CONTESTED", "ACQUIRE"
        elif pb >= 0.9:
            status, advice = "ESTABLISHED", "ANSWER"
        elif pb >= 0.5:
            status, advice = "TENTATIVE", "HEDGE"
        else:
            status, advice = "UNKNOWN", "ACQUIRE"
        return Belief(slot, best, pb, status, ranked[1:], advice)

    def belief(self, subject, predicate, obj=None, now=None) -> Belief:
        now = self.clock() if now is None else now
        return self._belief(self._slot(_n(subject), _n(predicate), None if obj is None else _n(obj)), now)

    def explain(self, subject, predicate, obj=None) -> List[dict]:
        """Provenance for citing or auditing a belief."""
        slot = self._slot(_n(subject), _n(predicate), None if obj is None else _n(obj))
        return [dict(obj=o, origin=orig, source=s, t=t)
                for o, origins in self.ev.get(slot, {}).items() for orig, (s, t) in origins.items()]

    # ---- ingest ----------------------------------------------------------
    def ingest(self, claim: Claim, source: str, origin: Optional[str] = None,
               t: Optional[float] = None) -> Ingested:
        source = _n(source)
        if source not in self.sources:
            self.register_source(source, 0.6)
        origin = _n(origin or source)
        t = self.clock() if t is None else t
        s, p, o = _n(claim.subject), _n(claim.predicate), _n(claim.obj)
        slot = self._slot(s, p, o)
        ev = self.ev.setdefault(slot, {})
        before = self._belief(slot, t)
        if origin in ev.get(o, {}):                       # same origin, same statement
            return Ingested("DUPLICATE", "SKIP", 0.0, before.confidence, before.confidence)

        dist, p_unk = self._dist(slot, t)
        surprisal = -math.log2(dist.get(o, p_unk / self.open_n))
        kind = "NEW" if not dist else ("CONFIRMS" if o == before.best else "CONFLICTS")

        for other in list(ev):                            # an origin's latest word wins
            if other != o:
                ev[other].pop(origin, None)
                if not ev[other]:
                    del ev[other]
        ev.setdefault(o, {})[origin] = (source, t)
        after = self._belief(slot, t)

        h = self.horizon.value()
        if self.n < self.warmup or h is None:
            action = "ABSORB"
        elif surprisal > h:
            action = "EXPAND"
            self.importance[slot] = max(self.importance.get(slot, 0.0), self.auto_importance)
        else:
            action = "COMPRESS"
        self.horizon.update(surprisal)
        self.n += 1
        return Ingested(kind, action, surprisal, before.confidence, after.confidence)

    # ---- planning --------------------------------------------------------
    def plan(self, budget: float, min_voi: float = 0.05, now: Optional[float] = None) -> List[Acquisition]:
        """Greedy value-of-information plan. One source per slot per call (sources already heard from are skipped unless repeatable); re-plan after ingesting.
        Heuristic: a source of reliability r resolves ~(2r-1) of the current doubt."""
        now = self.clock() if now is None else now
        options = []
        for slot, imp in self.importance.items():
            if imp <= 0:
                continue
            b = self._belief(slot, now)
            doubt = 1.0 - b.confidence
            used = {src for origins in self.ev.get(slot, {}).values() for src, _ in origins.values()}
            best = None
            for src in self.sources.values():
                if (src.name in used and not src.repeatable) or (src.covers is not None and slot[1] not in src.covers):
                    continue
                voi = imp * doubt * (2 * src.reliability - 1) / src.cost
                if best is None or voi > best.voi:
                    best = Acquisition(slot[0], slot[1], src.name, voi, src.cost)
            if best and best.voi >= min_voi:
                options.append(best)
        options.sort(key=lambda a: (-a.voi, a.subject, a.predicate))
        chosen, spent = [], 0.0
        for a in options:
            if spent + a.cost <= budget:
                chosen.append(a)
                spent += a.cost
        return chosen

    # ---- persistence -----------------------------------------------------
    def to_dict(self) -> dict:
        return dict(
            open_n=self.open_n, warmup=self.warmup, auto_importance=self.auto_importance, n=self.n,
            sources=[[s.name, s.reliability, s.cost, sorted(s.covers) if s.covers else None, s.repeatable]
                     for s in self.sources.values()],
            half_life=self.half_life, multi=sorted(self.multi),
            horizon=dict(k=self.horizon.k, ema=self.horizon.ema, min_std=self.horizon.min_std,
                         mean=self.horizon.mean, var=self.horizon.var, n=self.horizon.n),
            slots=[dict(slot=list(k), importance=self.importance.get(k),
                        ev={o: {orig: list(v) for orig, v in origins.items()} for o, origins in d.items()})
                   for k, d in self.ev.items()],
            wanted=[[list(k), v] for k, v in self.importance.items() if k not in self.ev],
        )

    @classmethod
    def from_dict(cls, d: dict, clock: Callable[[], float] = time.time) -> "NKPEngine":
        e = cls(clock, d["open_n"], d["warmup"], d["auto_importance"])
        e.n = d["n"]
        for name, r, c, cov, rep_ in d["sources"]:
            e.register_source(name, r, c, cov, rep_)
        e.half_life, e.multi = dict(d["half_life"]), set(d["multi"])
        h = d["horizon"]
        e.horizon = Horizon(h["k"], h["ema"], h["min_std"])
        e.horizon.mean, e.horizon.var, e.horizon.n = h["mean"], h["var"], h["n"]
        for rec in d["slots"]:
            k = tuple(rec["slot"])
            e.ev[k] = {o: {orig: tuple(v) for orig, v in origins.items()} for o, origins in rec["ev"].items()}
            if rec["importance"] is not None:
                e.importance[k] = rec["importance"]
        for k, v in d["wanted"]:
            e.importance[tuple(k)] = v
        return e

    def save(self, path: str) -> None:
        with open(path, "w") as f:
            json.dump(self.to_dict(), f)

    @classmethod
    def load(cls, path: str, clock: Callable[[], float] = time.time) -> "NKPEngine":
        with open(path) as f:
            return cls.from_dict(json.load(f), clock)


# --------------------------------------------------------------------------
# Demo and self-tests (synthetic entities so no real-world facts are implied)
# --------------------------------------------------------------------------
def _fresh(**kw) -> NKPEngine:
    e = NKPEngine(clock=lambda: 0.0, **kw)
    e.register_source("docs", 0.90, cost=2.0)
    e.register_source("wiki", 0.75, cost=1.0)
    e.register_source("forum", 0.60, cost=1.0)
    return e


def _mature(e: NKPEngine) -> None:
    """A knowledge base that has seen mostly routine confirmations."""
    for i in range(6):
        e.ingest(Claim(f"lib{i}", "license", "mit"), "wiki", f"w{i}", t=0)
    for i in range(6):
        e.ingest(Claim(f"lib{i}", "license", "mit"), "docs", f"d{i}", t=0)
    for i in range(6):
        e.ingest(Claim(f"lib{i}", "license", "mit"), "forum", f"f{i}", t=0)


def demo() -> None:
    e = _fresh()
    e.set_half_life("latest_version", 30)
    stream = [
        (Claim("zorblib", "license", "mit"), "wiki", "page-1"),
        (Claim("zorblib", "license", "mit"), "docs", "repo-1"),
        (Claim("zorblib", "license", "mit"), "forum", "page-1"),      # echo of wiki's origin
        (Claim("zorblib", "language", "rust"), "wiki", "page-1"),
        (Claim("zorblib", "language", "rust"), "docs", "repo-1"),
        (Claim("zorblib", "license", "gpl"), "forum", "post-9"),      # challenge to belief
        (Claim("zorblib", "latest_version", "2.1"), "docs", "repo-1"),
    ]
    print(f"{'kind':<10} {'action':<9} {'bits':>5}  conf   claim")
    for c, src, org in stream:
        r = e.ingest(c, src, org, t=0)
        print(f"{r.kind:<10} {r.action:<9} {r.surprisal:5.1f}  {r.confidence_before:.2f}->{r.confidence_after:.2f}  "
              f"{c.subject}.{c.predicate}={c.obj} [{src}]")
    print()
    for pred in ("license", "language", "latest_version", "maintainer"):
        for now in (0, 60) if pred == "latest_version" else (0,):
            b = e.belief("zorblib", pred, now=now)
            print(f"{pred:<15} t={now:<3} best={b.best!s:<6} conf={b.confidence:.2f} {b.status:<11} -> {b.advice}")
    e.want("zorblib", "maintainer", importance=0.9)
    e.want("zorblib", "latest_version", importance=0.8)
    print("\nplan(budget=3) at t=60:")
    for a in e.plan(3, now=60):
        print(f"  ask {a.source:<6} about {a.subject}.{a.predicate:<15} voi={a.voi:.2f} cost={a.cost}")


def run_tests() -> None:
    # T1: confidence is calibrated to source reliability and adds by independent origin.
    e = _fresh()
    e.ingest(Claim("a", "p", "x"), "wiki", "o1", t=0)
    assert abs(e.belief("a", "p", now=0).confidence - 0.75) < 1e-9
    e.ingest(Claim("a", "p", "x"), "wiki", "o2", t=0)
    assert abs(e.belief("a", "p", now=0).confidence - 9 / 10) < 1e-9        # 3*3=9 -> 9/10

    # T2: echo defence - the same origin repeated, or via other channels, adds nothing.
    e = _fresh()
    e.ingest(Claim("a", "p", "x"), "wiki", "paper-1", t=0)
    c0 = e.belief("a", "p", now=0).confidence
    for src in ("wiki", "docs", "forum"):
        r = e.ingest(Claim("a", "p", "x"), src, "paper-1", t=0)
        assert r.kind == "DUPLICATE" and r.action == "SKIP"
    assert e.belief("a", "p", now=0).confidence == c0

    # T3: a challenge to a strong belief is the most surprising event and is flagged,
    #     but a lone weak challenge lowers confidence without flipping the answer
    #     and is NOT worth spending on (efficiency: eligible, not scheduled).
    e = _fresh()
    e.register_source("search", 0.80, cost=1.0, repeatable=True)
    _mature(e)
    e.ingest(Claim("z", "color", "blue"), "docs", "d-a", t=0)
    e.ingest(Claim("z", "color", "blue"), "wiki", "w-a", t=0)
    before = e.belief("z", "color", now=0)
    new_slot = e.ingest(Claim("q", "color", "red"), "wiki", "w-q", t=0)
    r = e.ingest(Claim("z", "color", "green"), "forum", "f-a", t=0)
    after = e.belief("z", "color", now=0)
    assert r.kind == "CONFLICTS" and r.surprisal > new_slot.surprisal
    assert r.action == "EXPAND", r
    assert after.best == "blue" and after.confidence < before.confidence
    assert e.importance[("z", "color")] > 0                               # queued for attention...
    assert ("z", "color") not in {(a.subject, a.predicate) for a in e.plan(10, now=0)}  # ...not chased

    # T3b: when the challenge is credible enough to make the slot CONTESTED, the
    #      planner schedules verification, using a repeatable source even though
    #      every named source has already spoken.
    e = _fresh()
    e.register_source("search", 0.80, cost=1.0, repeatable=True)
    _mature(e)
    e.ingest(Claim("z", "color", "blue"), "docs", "d-a", t=0)
    e.ingest(Claim("z", "color", "green"), "wiki", "w-a", t=0)
    e.ingest(Claim("z", "color", "green"), "forum", "f-a", t=0)
    e.ingest(Claim("z", "color", "green"), "forum", "f-b", t=0)        # odds 3*1.5*1.5=6.75 vs 9
    assert e.belief("z", "color", now=0).status == "CONTESTED"
    picks = [(a.subject, a.predicate, a.source) for a in e.plan(10, now=0)]
    assert ("z", "color", "search") in picks, picks

    # T4: routine confirmation of a mature belief is absorbed silently and not queued.
    e = _fresh()
    _mature(e)
    r = e.ingest(Claim("lib0", "license", "mit"), "docs", "d-extra", t=0)
    assert r.kind == "CONFIRMS" and r.action == "COMPRESS" and r.surprisal < 1.0, r
    assert ("lib0", "license") not in {(a.subject, a.predicate) for a in e.plan(100, now=0)}

    # T5: planner ranks by value and cost, respects budget, never re-asks a used source.
    e = _fresh()
    e.want("big", "fact", importance=1.0)
    e.want("small", "fact", importance=0.2)
    e.ingest(Claim("half", "fact", "x"), "forum", "f1", t=0)
    e.want("half", "fact", importance=1.0)
    plan = e.plan(budget=100, now=0)
    order = [(a.subject, a.source) for a in plan]
    assert order[0][0] == "big" and order.index(("big", order[0][1])) < [a.subject for a in plan].index("small")
    assert all(a.source != "forum" for a in plan if a.subject == "half")     # forum already spoke
    assert sum(a.cost for a in e.plan(budget=1.0, now=0)) <= 1.0
    assert e.plan(budget=0, now=0) == []

    # T6: volatile facts decay into re-acquisition; stable facts don't.
    e = _fresh()
    e.set_half_life("version", 10)
    for pred in ("version", "license"):
        e.ingest(Claim("a", pred, "1"), "wiki", "o1", t=0)
        e.ingest(Claim("a", pred, "1"), "docs", "o2", t=0)
        e.want("a", pred, importance=1.0)
    assert e.belief("a", "version", now=0).advice == "ANSWER"
    assert e.belief("a", "version", now=40).advice == "ACQUIRE"
    assert e.belief("a", "license", now=40).advice == "ANSWER"
    assert [a.predicate for a in e.plan(10, now=40)] == ["version"]

    # T7: an origin that changes its statement moves the belief and isn't double-counted.
    e = _fresh()
    e.ingest(Claim("a", "p", "old"), "docs", "site", t=0)
    e.ingest(Claim("a", "p", "new"), "docs", "site", t=1)
    b = e.belief("a", "p", now=1)
    assert b.best == "new" and not b.alternatives and abs(b.confidence - 0.9) < 1e-9

    # T8: multi-valued predicates accumulate instead of conflicting.
    e = _fresh()
    e.mark_multi_valued("has_tag")
    e.ingest(Claim("a", "has_tag", "fast"), "wiki", "o1", t=0)
    r = e.ingest(Claim("a", "has_tag", "safe"), "wiki", "o1", t=0)
    assert r.kind == "NEW"
    assert e.belief("a", "has_tag", "fast", now=0).confidence == e.belief("a", "has_tag", "safe", now=0).confidence

    # T9: an unrelated contested slot advises ACQUIRE, an established one ANSWER.
    e = _fresh()
    e.ingest(Claim("a", "p", "x"), "wiki", "o1", t=0)
    e.ingest(Claim("a", "p", "y"), "wiki", "o2", t=0)
    assert e.belief("a", "p", now=0).status == "CONTESTED"
    assert e.belief("a", "p", now=0).advice == "ACQUIRE"
    assert e.belief("nobody", "nothing", now=0).status == "UNKNOWN"

    # T10: persistence round-trip preserves belief, plan and future behaviour.
    e = _fresh()
    _mature(e)
    e.ingest(Claim("z", "color", "blue"), "docs", "d-a", t=0)
    e.want("z", "shape", 0.7)
    e2 = NKPEngine.from_dict(json.loads(json.dumps(e.to_dict())), clock=lambda: 0.0)
    assert e2.belief("z", "color", now=0) == e.belief("z", "color", now=0)
    assert e2.plan(10, now=0) == e.plan(10, now=0)
    c = Claim("z", "color", "green")
    assert e.ingest(c, "forum", "f", t=0) == e2.ingest(c, "forum", "f", t=0)

    print("all 11 tests passed")


if __name__ == "__main__":
    run_tests() if "--test" in sys.argv else demo()
