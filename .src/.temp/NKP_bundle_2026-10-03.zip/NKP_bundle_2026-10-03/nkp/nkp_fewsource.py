"""
Scenario C: few sources, uninformative declared reliabilities  (the regime the Colab demo exposed).

Three sources cost 1 each and answer with true reliability .90 / .75 / .30, but ALL are declared
at .70 -- so declared priors carry no information and only learning can separate them.
40 facts, 25% volatile.  Budgets are queries per step: 1, 2, 3.  Reuses the nkp_bench world/agents.

PRE-REGISTERED CRITERIA (written before any run):
  C1  v4 beats the windowed baseline on accuracy by > 2 SE at budgets 1, 2 and 3
  C2  v4 beats "v4 - reliability learning" by > 2 SE at budgets 1, 2 and 3
  C3  v4 ECE is not significantly worse than the baseline's at any budget

    python nkp_fewsource.py --dev      seeds 0-19
    python nkp_fewsource.py --test     fresh seeds 300-329 (run once)
"""
import json
import math
import statistics
import sys

import nkp_bench as B

B.SCENARIOS["C"] = dict(K=6, N=40, LAMBDA=1 / 40, VOL_RULE=(1, 4), SPECS=[
    dict(name="good", r=.90, cost=1.0, lag=3, up=None, cp=0.0, decl=.70),
    dict(name="mid",  r=.75, cost=1.0, lag=3, up=None, cp=0.0, decl=.70),
    dict(name="bad",  r=.30, cost=1.0, lag=3, up=None, cp=0.0, decl=.70),
])

# candidate v4.1 = v4 with the Bayes-correct K-value likelihood; the same criteria apply to it
B.AGENTS.append(lambda w, r: B.NKPv4Agent(w, r, name="v4.1 (K-aware)", k_aware=True))
B.AGENTS.append(lambda w, r: B.NKPv4Agent(w, r, name="v4.1 - learning", k_aware=True, learn_reliability=False))


def main():
    test = "--test" in sys.argv
    seeds = list(range(300, 330)) if test else list(range(20))
    B.use_scenario("C")
    results = {}
    for b in (1, 2, 3):
        runs = [B.run_once(s, b, True) for s in seeds]
        results[b] = runs
        B.print_config(f"scenario C, {b} quer{'y' if b == 1 else 'ies'}/step", runs)
    for cand, abl in (("NKP v4", "v4 - reliability learning"), ("v4.1 (K-aware)", "v4.1 - learning")):
        print(f"\nPRE-REGISTERED CRITERIA for {cand}")
        ok = True
        for b, runs in results.items():
            a, ae = B.paired(runs, cand, "acc")
            l, le = B.mean_se([r[cand]["acc"] - r[abl]["acc"] for r in runs])
            e, ee = B.paired(runs, cand, "ece")
            c1, c2, c3 = a - 2 * ae > 0, l - 2 * le > 0, e - 2 * ee <= 0
            ok &= c1 and c2 and c3
            print(f"  budget {b}:  C1 d-acc vs baseline {a:+.3f}±{ae:.3f} {'PASS' if c1 else 'FAIL'}   "
                  f"C2 vs {abl} {l:+.3f}±{le:.3f} {'PASS' if c2 else 'FAIL'}   "
                  f"C3 d-ECE {e:+.3f}±{ee:.3f} {'PASS' if c3 else 'FAIL'}")
        print("  OVERALL:", "PASS" if ok else "FAIL")
    json.dump({str(k): v for k, v in results.items()}, open(f"fewsource_{'test' if test else 'dev'}.json", "w"))


if __name__ == "__main__":
    main()
