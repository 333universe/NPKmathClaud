"""
NKP triage benchmark: which claims deserve verification when importance is UNKNOWN?

A stream of claims arrives (10/step plus novel events).  Each step the agent may flag k=2
claims for verification.  Verifying a claim RESOLVES its slot (a slot is never flagged again, and at
most one flag per slot per step).  A flag "hits" if the flagged claim was WRONG or its slot is a NOVEL
EVENT (new knowledge acquired).  Score = precision of flags; Random's precision is the base rate.
(Verification outcomes are not fed back into the belief engine -- a simplification.)

World: 4 sources (reliability .9/.8/.7/.3, all declared .7).  30% of claims open a brand-new
slot, so a NEW slot is common and belief surprisal alone cannot tell novel from mundane
(open-world regime).  Other claims hit one of the 40 most recent slots.
Three worlds decide how vocabulary relates to error/novelty:
  U1  wrong claims use RARE words          (text novelty helps by construction; habituation risk)
  U2  wrong claims use COMMON words        (text novelty has no signal about error: does it harm?)
  U3  as U2, plus novel events described with never-seen terms (text novelty = real novelty)

Strategies (all share one stream and one v4 engine, so comparisons are paired):
  Random | Belief (v4 surprisal) | Text-all (text model learns every claim) |
  Hybrid-all (max of z_belief, z_text: either alarm fires; text learns every claim) |
  Hybrid-verified (same rule, but the text model learns a slot's sentence only once >= 2 independent sources corroborate it and it is uncontested)

PRE-REGISTERED CRITERIA (written before any run; the combination rule was changed from a z-sum
to a z-max after DEV diagnostics showed the text signal is strong but noisy -- see nkp notes):
  P1a  Hybrid-verified beats Belief by > 2 SE in U3
  P1b  Hybrid-verified beats Belief by > 2 SE in U1
  P1c  Hybrid-verified is not significantly worse than Belief in U2 (does no harm)
  P2   Hybrid-verified beats Hybrid-all by > 2 SE in U1 (learning only from verified claims matters)
  Integrate the hybrid iff P1a, P1b, P1c all hold on fresh test seeds.

    python nkp_triage.py --dev [--U1 --U2 --U3] [--quick]   development, seeds 0-19
    python nkp_triage.py --test [--U1 ...]                  final, fresh seeds 100-139 (run once)
    python nkp_triage.py --dev|--test --report              aggregate saved scenario results
"""
from __future__ import annotations

import json
import math
import random
import statistics
import sys

from nkp_engine import PredictiveModel
from nkp_v4 import Claim, NKPv4

COMMON = ["normal", "expected", "stable", "nominal", "steady", "routine", "calm", "regular"]
RARE = ["critical", "failing", "corrupted", "abnormal", "strange", "odd", "unexpected", "anomalous"]
SOURCES = [("s1", .9), ("s2", .8), ("s3", .7), ("s4", .3)]
STEPS, PER_STEP, K_FLAG, WARM = 200, 10, 2, 20
P_NEW, P_NOVEL, RECENT = 0.30, 0.10, 40
STRATS = ["Random", "Belief", "Text-all", "Hybrid-all", "Hybrid-verified", "Hybrid-verified (sum)"]


def text_of(value, slot):
    return f"the status is {value} for item {slot % 3}."


def make_batches(seed, scen):
    rng = random.Random(seed)
    truth, recent, novel_n = {}, [], 0
    for _ in range(STEPS):
        batch = []
        for _ in range(PER_STEP):
            if rng.random() < P_NEW or not recent:
                sid = len(truth)
                truth[sid] = rng.choice(COMMON)
                recent.append(sid)
            else:
                sid = rng.choice(recent[-RECENT:])
            src, r = rng.choice(SOURCES)
            right = rng.random() < r
            if right:
                val = truth[sid]
            elif scen == "U1":
                val = rng.choice(RARE)
            else:
                val = rng.choice([w for w in COMMON if w != truth[sid]])
            batch.append(dict(slot=sid, src=src, val=val, wrong=not right, novel=False))
        if scen == "U3" and rng.random() < P_NOVEL:
            sid = len(truth)
            truth[sid] = f"zx{novel_n}"
            novel_n += 1
            for src, r in rng.sample(SOURCES, 3):
                right = rng.random() < r
                val = truth[sid] if right else rng.choice(COMMON)
                batch.append(dict(slot=sid, src=src, val=val, wrong=not right, novel=True))
        rng.shuffle(batch)
        yield batch


class Ema:
    def __init__(self, a=0.05):
        self.a, self.m, self.v, self.n = a, 0.0, 1.0, 0

    def z(self, x):
        return (x - self.m) / max(math.sqrt(self.v), 0.5)

    def update(self, x):
        if self.n == 0:
            self.m = x
        else:
            d = x - self.m
            self.m += self.a * d
            self.v = (1 - self.a) * (self.v + self.a * d * d)
        self.n += 1


def run_once(seed, scen):
    rng = random.Random(seed + 7919)
    eng = NKPv4(learn_reliability=True, detect_copies=False, domain_size=len(COMMON) + 1)
    for s, _ in SOURCES:
        eng.register_source(s, 0.7, 1.0)
    tm_all, tm_ver = PredictiveModel(), PredictiveModel()
    st_b, st_ta, st_tv = Ema(), Ema(), Ema()
    learned = set()
    hits = {k: 0 for k in STRATS}
    flags = {k: 0 for k in STRATS}
    resolved = {k: set() for k in STRATS}
    for t, batch in enumerate(make_batches(seed, scen)):
        feats = []
        for c in batch:
            text = text_of(c["val"], c["slot"])
            ta, _ = tm_all.surprisal(text)
            tv, _ = tm_ver.surprisal(text)
            obs = eng.observe(Claim(f"slot{c['slot']}", "status", c["val"]), c["src"], t)
            tm_all.learn(text)
            feats.append((obs.surprisal, ta, tv))
        for sid in {c["slot"] for c in batch}:                       # deferred, verified learning
            if sid in learned:
                continue
            b = eng.belief(f"slot{sid}", "status", t)
            if b.best is None or b.status == "CONTESTED":
                continue
            led = eng.ledger[(f"slot{sid}", "status")]
            if len({eng._find(s_) for s_, (v_, _) in led.items() if v_ == b.best}) >= 2:   # corroborated
                tm_ver.learn(text_of(b.best, sid))
                learned.add(sid)
        if t >= WARM:
            jit = [rng.random() * 1e-6 for _ in batch]
            scores = {
                "Random": [rng.random() for _ in batch],
                "Belief": [f[0] + j for f, j in zip(feats, jit)],
                "Text-all": [f[1] + j for f, j in zip(feats, jit)],
                "Hybrid-all": [max(st_b.z(f[0]), st_ta.z(f[1])) + j for f, j in zip(feats, jit)],
                "Hybrid-verified": [max(st_b.z(f[0]), st_tv.z(f[2])) + j for f, j in zip(feats, jit)],
                "Hybrid-verified (sum)": [st_b.z(f[0]) + st_tv.z(f[2]) + j for f, j in zip(feats, jit)],
            }
            for name, sc in scores.items():
                picked, used = 0, set()
                for i in sorted(range(len(batch)), key=lambda i: -sc[i]):
                    c = batch[i]
                    if c["slot"] in resolved[name] or c["slot"] in used:      # verification resolves a slot
                        continue
                    used.add(c["slot"])
                    resolved[name].add(c["slot"])
                    hits[name] += int(c["wrong"] or c["novel"])
                    flags[name] += 1
                    picked += 1
                    if picked == K_FLAG:
                        break
        for b_, ta_, tv_ in feats:
            st_b.update(b_)
            st_ta.update(ta_)
            st_tv.update(tv_)
    return {k: hits[k] / flags[k] for k in STRATS}


def mean_se(xs):
    return statistics.mean(xs), (statistics.stdev(xs) / math.sqrt(len(xs)) if len(xs) > 1 else 0.0)


def analyse(res):
    for scen in ("U1", "U2", "U3"):
        if scen not in res:
            continue
        runs = res[scen]
        print(f"\n{scen}  ({len(runs)} seeds)   precision of flags")
        print(f"{'strategy':<24}{'precision':>12}{'vs Belief (paired)':>24}")
        for k in STRATS:
            m, se = mean_se([r[k] for r in runs])
            if k in ("Belief", "Random"):
                d = "-"
            else:
                dm, dse = mean_se([r[k] - r["Belief"] for r in runs])
                d = f"{dm:+.3f}±{dse:.3f}"
            print(f"{k:<24}{m:>7.3f}±{se:.3f}{d:>24}")
    if not all(k in res for k in ("U1", "U2", "U3")):
        return

    def diff(scen, a, b):
        return mean_se([r[a] - r[b] for r in res[scen]])
    print("\nPRE-REGISTERED CRITERIA")
    ok = {}
    m, se = diff("U3", "Hybrid-verified", "Belief"); ok["P1a"] = m - 2 * se > 0
    print(f"  P1a U3 hybrid-verified - belief: {m:+.3f}±{se:.3f}  {'PASS' if ok['P1a'] else 'FAIL'}")
    m, se = diff("U1", "Hybrid-verified", "Belief"); ok["P1b"] = m - 2 * se > 0
    print(f"  P1b U1 hybrid-verified - belief: {m:+.3f}±{se:.3f}  {'PASS' if ok['P1b'] else 'FAIL'}")
    m, se = diff("U2", "Hybrid-verified", "Belief"); ok["P1c"] = m + 2 * se >= 0
    print(f"  P1c U2 hybrid-verified - belief: {m:+.3f}±{se:.3f}  {'PASS (no significant harm)' if ok['P1c'] else 'FAIL (harms)'}")
    m, se = diff("U1", "Hybrid-verified", "Hybrid-all"); ok["P2"] = m - 2 * se > 0
    print(f"  P2  U1 hybrid-verified - hybrid-all: {m:+.3f}±{se:.3f}  {'PASS' if ok['P2'] else 'FAIL'}")
    print("  INTEGRATE HYBRID:", "YES" if ok["P1a"] and ok["P1b"] and ok["P1c"] else "NO")


def main():
    mode = "test" if "--test" in sys.argv else "dev"
    seeds = list(range(100, 140)) if mode == "test" else list(range(20))
    if "--quick" in sys.argv:
        seeds = seeds[:3]
    chosen = [sc for sc in ("U1", "U2", "U3") if f"--{sc}" in sys.argv] or ["U1", "U2", "U3"]
    res = {}
    if "--report" in sys.argv:
        for sc in ("U1", "U2", "U3"):
            res[sc] = json.load(open(f"triage_{mode}_{sc}.json"))
    else:
        for sc in chosen:
            res[sc] = [run_once(sd, sc) for sd in seeds]
            with open(f"triage_{mode}_{sc}.json", "w") as f:
                json.dump(res[sc], f)
    analyse(res)


if __name__ == "__main__":
    main()
