"""
NKP benchmark: does the engine beat simple baselines?   (standard library only)

WORLD  60 facts (slots), each with one true value out of K=6.  Half are volatile
       (change with prob 1/40 per step); half are stable.  Slots carry importance 1-3.
SOURCES  Seven sources with hidden true reliability, cost and lag.  Each source keeps a
       persistent answer per slot (errors persist; re-asking gets the same answer until
       the source updates, `lag` steps after a change).  Traps:
         mirror1/2  copy wiki 95% of the time (cheap, echo the same errors)
         spam       true reliability .30 but declared .65
         drifter    reliability .90 -> .40 from step 150, declared .90
AGENTS  All get the same declared reliabilities/costs/importance/volatility and the
       same per-step budget.  Each step an agent may query (source, slot) pairs within
       budget; at evaluation steps it must report (answer, confidence) for every slot.
METRICS  importance-weighted accuracy; accuracy on volatile slots; Brier score and
       expected calibration error (ECE) of the reported confidence.
       Reported as mean +/- standard error over seeds; the worlds are paired across agents.

    python nkp_bench.py --dev [--quick]    development: scenario A, seeds 0-19
    python nkp_bench.py --test [--quick]   final: scenarios A and B, fresh seeds 100-129 (run once)
"""
from __future__ import annotations

import json
import math
import random
import statistics
import sys
import time

from nkp_acquire import Claim, NKPEngine
from nkp_v4 import Claim as V4Claim
from nkp_v4 import NKPv4

T, EVAL_FROM, EVAL_EVERY = 300, 60, 10

# name, r = true reliability, cost, lag (steps behind a change), up = copies this source,
# cp = copy probability, decl = DECLARED reliability (what agents are told), drift = (step, new r)
SCENARIOS = {
    "A": dict(K=6, N=60, LAMBDA=1 / 40, VOL_RULE=(1, 2), SPECS=[
        dict(name="docs",    r=.92, cost=3.0, lag=5,  up=None,   cp=0.0,  decl=.90),
        dict(name="wiki",    r=.80, cost=1.0, lag=10, up=None,   cp=0.0,  decl=.80),
        dict(name="forum",   r=.65, cost=1.0, lag=2,  up=None,   cp=0.0,  decl=.70),
        dict(name="mirror1", r=.50, cost=0.5, lag=3,  up="wiki", cp=.95,  decl=.75),
        dict(name="mirror2", r=.50, cost=0.5, lag=4,  up="wiki", cp=.95,  decl=.75),
        dict(name="spam",    r=.30, cost=0.5, lag=1,  up=None,   cp=0.0,  decl=.65),
        dict(name="drifter", r=.90, cost=1.5, lag=5,  up=None,   cp=0.0,  decl=.90, drift=(150, .40)),
    ]),
    # a different world: bigger domain, faster change, more volatile facts, a copy CHAIN,
    # an over-declared aggregator, an earlier-degrading source.  Built before v4 was run on it.
    "B": dict(K=8, N=80, LAMBDA=1 / 25, VOL_RULE=(2, 3), SPECS=[
        dict(name="primary",    r=.95, cost=4.0, lag=8,  up=None,          cp=0.0, decl=.93),
        dict(name="agency",     r=.85, cost=2.0, lag=4,  up=None,          cp=0.0, decl=.80),
        dict(name="aggregator", r=.75, cost=1.0, lag=12, up=None,          cp=0.0, decl=.85),
        dict(name="clone1",     r=.60, cost=0.4, lag=2,  up="aggregator",  cp=.90, decl=.80),
        dict(name="clone2",     r=.60, cost=0.4, lag=5,  up="clone1",      cp=.90, decl=.80),
        dict(name="noise",      r=.40, cost=0.3, lag=1,  up=None,          cp=0.0, decl=.70),
        dict(name="flaky",      r=.90, cost=1.0, lag=3,  up=None,          cp=0.0, decl=.85, drift=(120, .50)),
    ]),
}


def use_scenario(name: str) -> None:
    g, sc = globals(), SCENARIOS[name]
    g["K"], g["N"], g["LAMBDA"], g["VOL_RULE"], g["SPECS"] = sc["K"], sc["N"], sc["LAMBDA"], sc["VOL_RULE"], sc["SPECS"]
    g["NAMES"] = [x["name"] for x in sc["SPECS"]]
    g["BY_NAME"] = {x["name"]: x for x in sc["SPECS"]}
    g["DECL"] = {x["name"]: x["decl"] for x in sc["SPECS"]}
    g["COST"] = {x["name"]: x["cost"] for x in sc["SPECS"]}
    g["GUESS"] = (0, 1.0 / sc["K"])


use_scenario("A")


# --------------------------------------------------------------------------
# World
# --------------------------------------------------------------------------
class World:
    def __init__(self, seed: int, origin_visible: bool = True):
        self.rng = random.Random(seed)
        self.vis = origin_visible
        rng = self.rng
        self.volatile = [(i % VOL_RULE[1]) < VOL_RULE[0] for i in range(N)]
        self.importance = [rng.choice((1, 2, 3)) for _ in range(N)]
        self.truth = [rng.randrange(K) for _ in range(N)]
        self.val = {n: [None] * N for n in NAMES}
        self.pending = []
        for i in range(N):
            self._schedule(i, 0, immediate=True)

    def _r(self, sp, t):
        d = sp.get("drift")
        return d[1] if d and t >= d[0] else sp["r"]

    def _wrong(self, truth):
        return self.rng.choice([v for v in range(K) if v != truth])

    def _schedule(self, slot, t0, immediate=False):
        rng, truth, new = self.rng, self.truth[slot], {}
        for sp in SPECS:
            if sp["up"] and rng.random() < sp["cp"]:
                v = new[sp["up"]]
            else:
                v = truth if rng.random() < self._r(sp, t0) else self._wrong(truth)
            new[sp["name"]] = v
            if immediate:
                self.val[sp["name"]][slot] = v
            else:
                self.pending.append((t0 + sp["lag"], sp["name"], slot, v))

    def advance(self, t):
        for i in range(N):
            if self.volatile[i] and self.rng.random() < LAMBDA:
                self.truth[i] = self._wrong(self.truth[i])
                self._schedule(i, t)
        due = [p for p in self.pending if p[0] <= t]
        self.pending = [p for p in self.pending if p[0] > t]
        for _, name, slot, v in due:
            self.val[name][slot] = v

    def ask_fn(self, remaining):
        def ask(src, slot):
            if COST[src] > remaining[0] + 1e-9:
                return None
            remaining[0] -= COST[src]
            up = BY_NAME[src]["up"]
            return self.val[src][slot], (up if (self.vis and up) else src)
        return ask


# --------------------------------------------------------------------------
# Agents.  act(t, budget, ask) queries; report(t) -> [(answer, confidence)] * N
# --------------------------------------------------------------------------
GUESS = (0, 1.0 / K)


class Floor:
    name = "Floor (no queries)"

    def __init__(self, world, rng): pass
    def act(self, t, budget, ask): pass
    def report(self, t): return [GUESS] * N


class RandomLatest:
    name = "RandomLatest"

    def __init__(self, world, rng):
        self.rng, self.last = rng, [None] * N

    def act(self, t, budget, ask):
        for _ in range(60):
            slot, src = self.rng.randrange(N), self.rng.choice(NAMES)
            res = ask(src, slot)
            if res is not None:
                self.last[slot] = (res[0], DECL[src])

    def report(self, t):
        return [x if x else GUESS for x in self.last]


class RandomVote:
    name = "RandomVote"

    def __init__(self, world, rng):
        self.rng, self.obs = rng, [{} for _ in range(N)]

    def act(self, t, budget, ask):
        for _ in range(60):
            slot, src = self.rng.randrange(N), self.rng.choice(NAMES)
            res = ask(src, slot)
            if res is not None:
                self.obs[slot][src] = res[0]

    def report(self, t):
        out = []
        for o in self.obs:
            if not o:
                out.append(GUESS)
                continue
            counts = {}
            for v in o.values():
                counts[v] = counts.get(v, 0) + 1
            best = max(counts, key=lambda v: (counts[v], -v))
            out.append((best, counts[best] / len(o)))
        return out


class Baseline:
    """Strong simple baseline: naive-Bayes weighted vote over a hard time window, and the
    same importance x doubt refresh planner.  No origin de-duplication, no decay,
    no learning.  Whatever NKP adds beyond this is what we are actually measuring."""
    name = "Baseline (windowed NB)"

    def __init__(self, world, rng):
        self.vol, self.imp = world.volatile, world.importance
        self.obs = [{} for _ in range(N)]

    def _w(self, slot):
        return 1 / LAMBDA if self.vol[slot] else float("inf")

    def _belief(self, slot, t):
        score = {}
        for src, (t0, v) in self.obs[slot].items():
            if t - t0 <= self._w(slot):
                r = DECL[src]
                score[v] = score.get(v, 0.0) + math.log(r / (1 - r))
        if not score:
            return None, 0.0
        odds = {v: math.exp(s) for v, s in score.items()}
        z = 1 + sum(odds.values())
        best = max(odds, key=lambda v: (odds[v], -v))
        return best, odds[best] / z

    def act(self, t, budget, ask):
        order = sorted(range(N), key=lambda s: (-self.imp[s] * (1 - self._belief(s, t)[1]), s))
        for slot in order:
            used = {s for s, (t0, _) in self.obs[slot].items() if t - t0 <= self._w(slot)}
            options = [s for s in NAMES if s not in used]
            if not options:
                continue
            src = max(options, key=lambda s: ((2 * DECL[s] - 1) / COST[s], s))
            res = ask(src, slot)
            if res is not None:
                self.obs[slot][src] = (t, res[0])

    def report(self, t):
        out = []
        for s in range(N):
            b, c = self._belief(s, t)
            out.append((b, c) if b is not None else GUESS)
        return out


class NKPAgent:
    """Adapter around the v3 engine, used exactly as shipped."""

    def __init__(self, world, rng, repeatable=False, name="NKP v3"):
        self.name = name
        self.t = 0
        self.vol, self.imp = world.volatile, world.importance
        self.eng = NKPEngine(clock=lambda: self.t)
        for sp in SPECS:
            self.eng.register_source(sp["name"], sp["decl"], sp["cost"], repeatable=repeatable)
        self.eng.set_half_life("vol", math.log(2) / LAMBDA)
        for s in range(N):
            self.eng.want(f"s{s}", self._pred(s), self.imp[s] / 3)

    def _pred(self, s):
        return "vol" if self.vol[s] else "stab"

    def act(self, t, budget, ask):
        self.t = t
        for a in self.eng.plan(budget, min_voi=0.0, now=t):
            slot = int(a.subject[1:])
            res = ask(a.source, slot)
            if res is not None:
                self.eng.ingest(Claim(a.subject, a.predicate, f"v{res[0]}"), a.source, origin=res[1], t=t)

    def report(self, t):
        out = []
        for s in range(N):
            b = self.eng.belief(f"s{s}", self._pred(s), now=t)
            out.append((int(b.best[1:]), b.confidence) if b.best else GUESS)
        return out


class NKPv4Agent:
    def __init__(self, world, rng, name="NKP v4", **flags):
        self.name = name
        self.vol, self.imp = world.volatile, world.importance
        self.eng = NKPv4(domain_size=K, **flags)
        for sp in SPECS:
            self.eng.register_source(sp["name"], sp["decl"], sp["cost"])
        self.eng.set_half_life("vol", math.log(2) / LAMBDA)
        for s in range(N):
            self.eng.want(f"s{s}", self._pred(s), self.imp[s] / 3)

    def _pred(self, s):
        return "vol" if self.vol[s] else "stab"

    def act(self, t, budget, ask):
        for a in self.eng.plan(budget, t):
            res = ask(a.source, int(a.subject[1:]))
            if res is not None:
                self.eng.observe(V4Claim(a.subject, a.predicate, f"v{res[0]}"), a.source, t, origin=res[1])

    def report(self, t):
        out = []
        for s in range(N):
            b = self.eng.belief(f"s{s}", self._pred(s), t)
            out.append((int(b.best[1:]), b.confidence) if b.best else GUESS)
        return out


AGENTS = [
    lambda w, r: Floor(w, r),
    lambda w, r: Baseline(w, r),
    lambda w, r: NKPAgent(w, r),
    lambda w, r: NKPv4Agent(w, r),
    lambda w, r: NKPv4Agent(w, r, name="v4 - reliability learning", learn_reliability=False),
    lambda w, r: NKPv4Agent(w, r, name="v4 - copy detection", detect_copies=False),
]
BASE = "Baseline (windowed NB)"


# --------------------------------------------------------------------------
# Metrics and runner
# --------------------------------------------------------------------------
def score(items):
    """items: (correct, confidence, importance, volatile)"""
    wsum = sum(i[2] for i in items)
    acc = sum(i[0] * i[2] for i in items) / wsum
    vol = [i[0] for i in items if i[3]]
    brier = sum((i[1] - i[0]) ** 2 for i in items) / len(items)
    ece = 0.0
    for b in range(10):
        bin_ = [i for i in items if min(int(i[1] * 10), 9) == b]
        if bin_:
            ece += len(bin_) / len(items) * abs(sum(i[0] for i in bin_) / len(bin_) - sum(i[1] for i in bin_) / len(bin_))
    return dict(acc=acc, acc_vol=sum(vol) / len(vol), brier=brier, ece=ece)


def run_once(seed, budget, origin_visible=True):
    world = World(seed, origin_visible)
    agents = [f(world, random.Random(seed * 100 + k)) for k, f in enumerate(AGENTS)]
    items = {a.name: [] for a in agents}
    for t in range(1, T + 1):
        world.advance(t)
        for a in agents:
            a.act(t, budget, world.ask_fn([budget]))
        if t >= EVAL_FROM and t % EVAL_EVERY == 0:
            for a in agents:
                for s, (ans, conf) in enumerate(a.report(t)):
                    items[a.name].append((int(ans == world.truth[s]), min(max(conf, 0.0), 1.0),
                                          world.importance[s], world.volatile[s]))
    return {n: score(v) for n, v in items.items()}


def mean_se(xs):
    return statistics.mean(xs), (statistics.stdev(xs) / math.sqrt(len(xs)) if len(xs) > 1 else 0.0)


def paired(runs, agent, metric):
    return mean_se([r[agent][metric] - r[BASE][metric] for r in runs])


def print_config(title, runs):
    names = list(runs[0])
    print(f"\n{title}   ({len(runs)} seeds)")
    print(f"{'agent':<28}{'accuracy':>10}{'d-acc vs base':>17}{'acc(vol)':>10}{'ECE':>8}{'d-ECE vs base':>17}")
    for n in names:
        acc = mean_se([r[n]["acc"] for r in runs])[0]
        vol = mean_se([r[n]["acc_vol"] for r in runs])[0]
        ece = mean_se([r[n]["ece"] for r in runs])[0]
        if n == BASE:
            da = de = "-"
        else:
            m, se = paired(runs, n, "acc")
            da = f"{m:+.3f}±{se:.3f}"
            m, se = paired(runs, n, "ece")
            de = f"{m:+.3f}±{se:.3f}"
        print(f"{n:<28}{acc:>10.3f}{da:>17}{vol:>10.3f}{ece:>8.3f}{de:>17}")


def verdict(results, agent="NKP v4"):
    """Pre-registered: accuracy gain > 2 SE over the baseline, and ECE not significantly worse."""
    print(f"\nPRE-REGISTERED VERDICT for {agent}  (accuracy gain > 2 SE; ECE not significantly worse)")
    all_pass = True
    for key, runs in results.items():
        (m_a, se_a), (m_e, se_e) = paired(runs, agent, "acc"), paired(runs, agent, "ece")
        ok_a, ok_e = m_a - 2 * se_a > 0, m_e - 2 * se_e <= 0
        all_pass &= ok_a and ok_e
        scen, vis, b = key
        print(f"  scenario {scen}  origins {'visible' if vis else 'hidden ':<7} budget {b}:  "
              f"d-acc {m_a:+.3f}±{se_a:.3f} {'PASS' if ok_a else 'FAIL'}   d-ECE {m_e:+.3f}±{se_e:.3f} {'PASS' if ok_e else 'FAIL'}")
    print("  OVERALL:", "PASS" if all_pass else "FAIL")


def main():
    mode = "test" if "--test" in sys.argv else "dev"
    quick = "--quick" in sys.argv
    scenarios = ["A", "B"] if mode == "test" else ["A"]
    seeds = list(range(100, 130)) if mode == "test" else list(range(20))   # disjoint from dev seeds
    if quick:
        seeds = seeds[:3]
    t0 = time.time()
    results = {}
    for sc in scenarios:
        use_scenario(sc)
        for vis in (True, False):
            for b in (2, 4, 8):
                runs = [run_once(sd, b, vis) for sd in seeds]
                results[(sc, vis, b)] = runs
                print_config(f"scenario {sc}, budget {b}/step, origins {'visible' if vis else 'HIDDEN'}", runs)
    for agent in ("NKP v3", "NKP v4"):
        verdict(results, agent)
    with open(f"bench_{mode}.json", "w") as f:
        json.dump({f"{k[0]}|{k[1]}|{k[2]}": v for k, v in results.items()}, f)
    print(f"\n{time.time() - t0:.0f}s")


if __name__ == "__main__":
    main()
