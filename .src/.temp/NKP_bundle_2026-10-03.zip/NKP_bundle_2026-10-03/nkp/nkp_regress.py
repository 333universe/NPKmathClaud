"""
Regression check for v4.1 (K-aware) in worlds A and B at budget 4, both origin settings, FRESH seeds 400-429.

PRE-REGISTERED (written before any run):
  R1  v4.1 accuracy - v4 accuracy is not significantly negative in any cell   (mean + 2 SE >= 0)
  R2  v4.1 ECE is not significantly worse than the baseline's in any cell     (mean - 2 SE <= 0)
  info: R3 v4.1 ECE < v4 ECE ;  R4 v4.1 accuracy gain over baseline > 2 SE
  Adopt K-aware as the default iff R1 and R2 hold in every cell.

    python nkp_regress.py A     |     python nkp_regress.py B
"""
import sys
import nkp_bench as B

B.AGENTS.append(lambda w, r: B.NKPv4Agent(w, r, name="v4.1 (K-aware)", k_aware=True))
sc = sys.argv[1]
B.use_scenario(sc)
seeds = list(range(400, 430))
for vis in (True, False):
    runs = [B.run_once(s, 4, vis) for s in seeds]
    print(f"\nscenario {sc}, budget 4, origins {'visible' if vis else 'HIDDEN'}  ({len(seeds)} seeds)")
    print(f"{'agent':<26}{'accuracy':>10}{'ECE':>8}")
    for n in ("Baseline (windowed NB)", "NKP v4", "v4.1 (K-aware)"):
        print(f"{n:<26}{B.mean_se([r[n]['acc'] for r in runs])[0]:>10.3f}{B.mean_se([r[n]['ece'] for r in runs])[0]:>8.3f}")
    d, de = B.mean_se([r["v4.1 (K-aware)"]["acc"] - r["NKP v4"]["acc"] for r in runs])
    e, ee = B.paired(runs, "v4.1 (K-aware)", "ece")
    ev, eve = B.mean_se([r["v4.1 (K-aware)"]["ece"] - r["NKP v4"]["ece"] for r in runs])
    a, ae = B.paired(runs, "v4.1 (K-aware)", "acc")
    print(f"  R1 acc v4.1 - v4:        {d:+.3f}±{de:.3f}  {'PASS' if d + 2 * de >= 0 else 'FAIL'}")
    print(f"  R2 ECE v4.1 - baseline:  {e:+.3f}±{ee:.3f}  {'PASS' if e - 2 * ee <= 0 else 'FAIL'}")
    print(f"  info R3 ECE v4.1 - v4:   {ev:+.3f}±{eve:.3f}   R4 acc v4.1 - baseline: {a:+.3f}±{ae:.3f} {'(>2SE)' if a - 2 * ae > 0 else '(not >2SE)'}")
