"""
NKP v4: knowledge-acquisition engine built around an OBSERVATION LEDGER.

What changed from v3 (each item answers a failure the benchmark exposed):
  * Ledger, not evidence store.  We record what each source last said about each slot
    and WHEN.  Belief is a pure function of (ledger, reliabilities, clusters, time).
    Re-asking a source that repeats itself refreshes its timestamp (v3 dropped it).
  * Planner values NEW information only.  Asking source i about slot s is worth
    importance * doubt * (2r-1) * novelty / cost, where novelty is 1 if nobody in i's
    dependence cluster has spoken, otherwise P(the answer has changed since) -- 0 for
    stable facts, growing with time for volatile ones.  (v3 looped on echo sources
    and never refreshed volatile facts.)
  * Reliability is LEARNED per (source, predicate) by incremental EM: after each
    observation, the slot's posterior given ALL evidence is the expected correctness of
    every source's current answer there; a slot's contribution is replaced (not added)
    when it updates, and estimates are shrunk toward the declared prior.  (A first
    version scored sources against a leave-one-out consensus; the benchmark showed
    that biases every estimate toward the consensus's own accuracy -- docs, right
    93% of the time, was learned as 72% -- and it made the engine worse.)
  * Copy detection: two sources that agree far more than their reliabilities allow
    (a one-sided binomial z-test, z >= 4, plus a minimum effect size) are merged into one cluster and count as one vote (echo defence without needing
    origin labels).  Explicit origin labels, when given, are merged the same way.

v4.1 = NKPv4(k_aware=True), available as NKPv41.  The original belief step treated every wrong
answer as one lump, which made confidence too LOW whenever the domain has many values (found in the
few-source benchmark: everyone was underconfident and learned reliabilities sagged).  The K-aware
likelihood is the Bayes-correct one.  Evidence so far: scenario C (fresh seeds) passes all criteria;
worlds A/B at budget 4 (fresh seeds) show no accuracy regression and better calibration.  Not yet
re-run with v4.1: the full 12-cell A/B grid and the triage benchmark.

Standard library only.  Known gaps: single-valued predicates only, no persistence yet,
no horizon triage (v3 has it; the benchmark cannot exercise it because importance is given).
    python nkp_v4.py --test
"""
from __future__ import annotations

import math
import random
import sys
from dataclasses import dataclass
from typing import Dict, List, Optional, Tuple


def _n(x) -> str:
    return " ".join(str(x).lower().split())


@dataclass
class Src:
    name: str
    prior: float          # declared reliability
    cost: float


@dataclass
class Claim:
    subject: str
    predicate: str
    obj: str


@dataclass
class Belief:
    best: Optional[str]
    confidence: float
    status: str           # UNKNOWN | TENTATIVE | ESTABLISHED | CONTESTED
    advice: str           # ANSWER | HEDGE | ACQUIRE
    alternatives: List[Tuple[str, float]]


@dataclass
class Observed:
    kind: str             # NEW | CONFIRMS | CONFLICTS | RECONFIRM
    surprisal: float
    confidence_before: float
    confidence_after: float


@dataclass
class Acquisition:
    subject: str
    predicate: str
    source: str
    voi: float
    cost: float


class NKPv4:
    def __init__(self, open_n: int = 1000, domain_size: int = 6, prior_strength: float = 5.0,
                 dep_margin: float = 0.15, dep_min_n: int = 12, dep_z: float = 4.0,
                 pair_window: float = 5.0, learn_reliability: bool = True,
                 detect_copies: bool = True, k_aware: bool = False):
        self.open_n, self.domain_size = open_n, domain_size
        self.prior_strength = prior_strength
        self.dep_margin, self.dep_min_n, self.dep_z, self.pair_window = dep_margin, dep_min_n, dep_z, pair_window
        self.learn, self.copies = learn_reliability, detect_copies
        self.k_aware = k_aware      # use the Bayes-correct K-value likelihood (see _dist)
        self.sources: Dict[str, Src] = {}
        self.ledger: Dict[tuple, Dict[str, Tuple[str, float]]] = {}
        self.importance: Dict[tuple, float] = {}
        self.half_life: Dict[str, float] = {}
        self.parent: Dict[str, str] = {}
        self.rel: Dict[Tuple[str, str], List[float]] = {}           # (source, predicate) -> [sum p, count]
        self.contrib: Dict[tuple, Dict[str, float]] = {}            # slot -> source -> current E-step value
        self.pair: Dict[Tuple[str, str, str], List[int]] = {}

    # ---- configuration ---------------------------------------------------
    def register_source(self, name, reliability, cost=1.0) -> None:
        self.sources[_n(name)] = Src(_n(name), float(reliability), float(cost))

    def set_half_life(self, predicate, half_life) -> None:
        self.half_life[_n(predicate)] = float(half_life)

    def want(self, subject, predicate, importance=1.0) -> None:
        self.importance[(_n(subject), _n(predicate))] = importance

    # ---- clusters (union-find over source and origin names) ---------------
    def _find(self, x: str) -> str:
        self.parent.setdefault(x, x)
        while self.parent[x] != x:
            self.parent[x] = self.parent[self.parent[x]]
            x = self.parent[x]
        return x

    def _union(self, a: str, b: str) -> None:
        ra, rb = self._find(a), self._find(b)
        if ra != rb:
            self.parent[max(ra, rb)] = min(ra, rb)

    def clusters(self) -> Dict[str, List[str]]:
        out: Dict[str, List[str]] = {}
        for s in self.sources:
            out.setdefault(self._find(s), []).append(s)
        return {k: sorted(v) for k, v in out.items() if len(v) > 1}

    # ---- reliability -------------------------------------------------------
    def reliability(self, src: str, pred: str) -> float:
        p = self.sources[src].prior
        if not self.learn:
            return p
        a, n = self.rel.get((src, pred), (0.0, 0.0))
        return (a + self.prior_strength * p) / (n + self.prior_strength)

    # ---- belief ------------------------------------------------------------
    def _dist(self, slot, now, exclude_root=None, decay=True, window=None):
        pred = slot[1]
        hl = self.half_life.get(pred)
        groups = {}
        for src, (v, t) in self.ledger.get(slot, {}).items():
            root = self._find(src)
            if exclude_root is not None and root == exclude_root:
                continue
            if window is not None and abs(now - t) > window:
                continue
            cand = (t, self.reliability(src, pred), v)          # freshest voice in a cluster speaks for it
            if root not in groups or cand[:2] > groups[root][:2]:
                groups[root] = cand
        raw: Dict[str, List[float]] = {}
        for t, r, v in groups.values():
            rr = min(max(r, 0.501), 0.999)
            w = math.log(rr / (1 - rr))
            if self.k_aware:
                w += math.log(self.domain_size - 1)      # a wrong source picks one of K-1 wrong values
            d = 0.5 ** (max(0.0, now - t) / hl) if (hl and decay) else 1.0
            e = raw.setdefault(v, [0.0, 0.0, 0.0])
            e[0] += w
            e[1] += w * d
            e[2] += w
        if self.k_aware:     # every value nobody voted for is a hypothesis of weight 1 (K - #voted of them)
            z = max(self.domain_size - len(raw), 0) + sum(math.exp(e[0]) for e in raw.values())
        else:                # original: all unvoted values lumped into a single hypothesis of weight 1
            z = 1.0 + sum(math.exp(e[0]) for e in raw.values())
        dist = {v: (e[1] / e[2]) * math.exp(e[0]) / z for v, e in raw.items()}
        return dist, 1.0 - sum(dist.values())

    def _belief(self, slot, now) -> Belief:
        dist, _ = self._dist(slot, now)
        ranked = sorted(dist.items(), key=lambda kv: (-kv[1], kv[0]))
        if not ranked:
            return Belief(None, 0.0, "UNKNOWN", "ACQUIRE", [])
        best, pb = ranked[0]
        second = ranked[1][1] if len(ranked) > 1 else 0.0
        if second >= 0.5 * pb:
            st, adv = "CONTESTED", "ACQUIRE"
        elif pb >= 0.9:
            st, adv = "ESTABLISHED", "ANSWER"
        elif pb >= 0.5:
            st, adv = "TENTATIVE", "HEDGE"
        else:
            st, adv = "UNKNOWN", "ACQUIRE"
        return Belief(best, pb, st, adv, ranked[1:])

    def belief(self, subject, predicate, now) -> Belief:
        return self._belief((_n(subject), _n(predicate)), now)

    # ---- observe -------------------------------------------------------------
    def observe(self, claim: Claim, source: str, t: float, origin: Optional[str] = None) -> Observed:
        source = _n(source)
        if source not in self.sources:
            self.register_source(source, 0.6)
        if origin is not None and _n(origin) != source:
            self._union(source, _n(origin))
        slot, v = (_n(claim.subject), _n(claim.predicate)), _n(claim.obj)
        before = self._belief(slot, t)
        dist, pu = self._dist(slot, t)
        surprisal = -math.log2(max(dist.get(v, pu / self.open_n), 1e-12))
        if self.copies:
            self._pairs(slot, source, v, t)
        led = self.ledger.setdefault(slot, {})
        prev = led.get(source)
        led[source] = (v, t)                                     # re-confirmation refreshes the timestamp
        if self.learn:
            self._em_update(slot, t)
        after = self._belief(slot, t)
        if prev is not None and prev[0] == v:
            kind = "RECONFIRM"
        elif not dist:
            kind = "NEW"
        else:
            kind = "CONFIRMS" if v == before.best else "CONFLICTS"
        return Observed(kind, surprisal, before.confidence, after.confidence)

    def _em_update(self, slot, t) -> None:
        """Incremental EM.  Only contemporaneous voices are compared (for volatile predicates a
        stored answer may predate a change), and a slot teaches us nothing until at least two
        independent clusters have spoken (with one voice the posterior just echoes the prior)."""
        pred = slot[1]
        win = self.pair_window if pred in self.half_life else None
        voices = {self._find(src) for src, (_, t2) in self.ledger[slot].items() if win is None or abs(t - t2) <= win}
        if len(voices) < 2:
            return
        dist, _ = self._dist(slot, t, decay=False, window=win)
        contrib = self.contrib.setdefault(slot, {})
        for src, (v, t2) in self.ledger[slot].items():
            if win is not None and abs(t - t2) > win:
                continue
            p = dist.get(v, 0.0)                                 # P(this source's current answer is the truth)
            st = self.rel.setdefault((src, pred), [0.0, 0.0])
            if src in contrib:                                   # replace, don't accumulate
                st[0] -= contrib[src]
                st[1] -= 1.0
            st[0] += p
            st[1] += 1.0
            contrib[src] = p

    def _pairs(self, slot, source, v, t) -> None:
        pred = slot[1]
        win = self.pair_window if pred in self.half_life else float("inf")
        for other, (w, t2) in self.ledger.get(slot, {}).items():
            if other == source or abs(t - t2) > win:
                continue
            i, j = sorted((source, other))
            st = self.pair.setdefault((i, j, pred), [0, 0])
            st[0] += 1
            st[1] += int(v == w)
            if st[0] >= self.dep_min_n and self._find(i) != self._find(j):
                # copies inflate each other's learned reliability, which would excuse their agreement;
                # judge independence against the LOWER of learned and declared reliability
                ri = min(self.reliability(i, pred), self.sources[i].prior)
                rj = min(self.reliability(j, pred), self.sources[j].prior)
                expected = ri * rj + (1 - ri) * (1 - rj) / (self.domain_size - 1)
                var = max(expected * (1 - expected), 0.05)
                z = (st[1] - st[0] * expected) / math.sqrt(st[0] * var)   # binomial z-score vs independence
                if st[1] / st[0] - expected > self.dep_margin and z >= self.dep_z:
                    self._union(i, j)

    # ---- planning ---------------------------------------------------------------
    def plan(self, budget: float, now: float, min_voi: float = 1e-3) -> List[Acquisition]:
        options = []
        for slot, imp in self.importance.items():
            pred = slot[1]
            hl = self.half_life.get(pred)
            lam = math.log(2) / hl if hl else 0.0
            doubt = 1.0 - self._belief(slot, now).confidence
            led = self.ledger.get(slot, {})
            best = None
            for s in self.sources.values():
                gain = 2 * self.reliability(s.name, pred) - 1
                if gain <= 0:
                    continue
                root = self._find(s.name)
                t_last = max((t for o, (_, t) in led.items() if self._find(o) == root), default=None)
                novelty = 1.0 if t_last is None else 1.0 - math.exp(-lam * (now - t_last))
                voi = imp * doubt * gain * novelty / s.cost
                if best is None or voi > best.voi:
                    best = Acquisition(slot[0], slot[1], s.name, voi, s.cost)
            if best and best.voi >= min_voi:
                options.append(best)
        options.sort(key=lambda a: (-a.voi, a.subject, a.predicate))
        chosen, spent = [], 0.0
        for a in options:
            if spent + a.cost <= budget + 1e-9:
                chosen.append(a)
                spent += a.cost
        return chosen


class NKPv41(NKPv4):
    """NKPv4 with the K-aware (Bayes-correct) likelihood on by default."""

    def __init__(self, **kwargs):
        kwargs.setdefault("k_aware", True)
        super().__init__(**kwargs)


# --------------------------------------------------------------------------
def run_tests() -> None:
    def eng(**kw):
        e = NKPv4(**kw)
        e.register_source("docs", 0.9, 2.0)
        e.register_source("wiki", 0.75, 1.0)
        e.register_source("forum", 0.6, 1.0)
        return e

    # T1: calibration with learning off: single source -> its reliability; independent pair -> odds multiply.
    e = eng(learn_reliability=False, detect_copies=False)
    e.observe(Claim("a", "p", "x"), "wiki", 0)
    assert abs(e.belief("a", "p", 0).confidence - 0.75) < 1e-9
    e.observe(Claim("a", "p", "x"), "docs", 0)
    assert abs(e.belief("a", "p", 0).confidence - 27 / 28) < 1e-9

    # T2: shared origin counts once, however many channels report it.
    e = eng(learn_reliability=False)
    e.observe(Claim("a", "p", "x"), "wiki", 0, origin="paper")
    c = e.belief("a", "p", 0).confidence
    e.observe(Claim("a", "p", "x"), "docs", 0, origin="paper")
    e.observe(Claim("a", "p", "x"), "forum", 0, origin="paper")
    assert abs(e.belief("a", "p", 0).confidence - 0.9) < 1e-9       # one vote: the most reliable freshest voice (docs)
    assert abs(c - 0.75) < 1e-9

    # T3: re-confirmation refreshes freshness (v3 dropped it as a duplicate) and never adds weight.
    e = eng(learn_reliability=False, detect_copies=False)
    e.set_half_life("v", 10)
    e.observe(Claim("a", "v", "1"), "wiki", 0)
    stale = e.belief("a", "v", 40).confidence
    r = e.observe(Claim("a", "v", "1"), "wiki", 40)
    assert r.kind == "RECONFIRM"
    fresh = e.belief("a", "v", 40).confidence
    assert stale < 0.1 and abs(fresh - 0.75) < 1e-9

    # T4: planner asks only for NEW information.
    e = eng(learn_reliability=False, detect_copies=False)
    e.set_half_life("vol", 20)
    e.want("s", "stab", 1.0)
    e.want("v", "vol", 1.0)
    for src in ("docs", "wiki", "forum"):
        e.observe(Claim("s", "stab", "1"), src, 0)
    e.observe(Claim("v", "vol", "1"), "docs", 0)
    p0 = {(a.subject, a.source) for a in e.plan(10, now=1)}
    assert not any(s == "s" for s, _ in p0), p0                    # every voice already heard, stable fact
    assert ("v", "docs") not in p0                                  # just asked, nothing new to hear
    p1 = {(a.subject, a.source) for a in e.plan(10, now=60)}
    assert ("v", "docs") in p1 or ("v", "wiki") in p1               # volatile fact goes stale -> refresh
    e2 = eng(learn_reliability=False, detect_copies=False)
    e2.want("s", "stab", 1.0)
    e2.observe(Claim("s", "stab", "1"), "wiki", 0, origin="paper")
    e2.register_source("mirror", 0.75, 0.1)
    e2.observe(Claim("s", "stab", "1"), "mirror", 0, origin="paper")
    assert all(a.source not in ("wiki", "mirror") for a in e2.plan(10, now=5))   # same origin: nothing new

    # T5: reliability is learned: a source that keeps disagreeing loses trust, the others keep it.
    rng = random.Random(1)
    e = eng()
    e.register_source("bad", 0.8, 1.0)
    for i in range(60):
        truth = str(rng.randrange(6))
        for src in ("docs", "wiki", "forum"):
            e.observe(Claim(f"s{i}", "p", truth), src, i)
        e.observe(Claim(f"s{i}", "p", str((int(truth) + 1) % 6)), "bad", i)
    assert e.reliability("bad", "p") < 0.5 < e.reliability("docs", "p")
    assert e.reliability("docs", "p") > 0.8

    # T6: copy detection merges a clone of a source, and only the clone.
    rng = random.Random(2)
    e = NKPv4()
    for s in ("a", "b", "c", "clone"):
        e.register_source(s, 0.7, 1.0)
    for i in range(40):
        truth = rng.randrange(6)
        vals = {s: (truth if rng.random() < 0.7 else (truth + 1 + rng.randrange(5)) % 6) for s in ("a", "b", "c")}
        vals["clone"] = vals["c"] if rng.random() < 0.95 else rng.randrange(6)
        for s, v in vals.items():
            e.observe(Claim(f"s{i}", "p", str(v)), s, i)
    cl = e.clusters()
    assert cl and sorted(sum(cl.values(), [])) == ["c", "clone"], cl

    # T7: K-aware likelihood is Bayes-correct: two independent r=.7 sources agreeing, K=6.
    e = NKPv4(learn_reliability=False, detect_copies=False, k_aware=True, domain_size=6)
    e.register_source("a", 0.7)
    e.register_source("b", 0.7)
    e.observe(Claim("x", "p", "1"), "a", 0)
    assert abs(e.belief("x", "p", 0).confidence - 0.7) < 1e-9                     # single vote -> its accuracy
    e.observe(Claim("x", "p", "1"), "b", 0)
    want = 0.49 / (0.49 + 0.09 / 5)                                                # r1 r2 / (r1 r2 + (1-r1)(1-r2)/(K-1))
    assert abs(e.belief("x", "p", 0).confidence - want) < 1e-9, e.belief("x", "p", 0).confidence

    assert NKPv41().k_aware and not NKPv4().k_aware
    print("all 7 tests passed")


if __name__ == "__main__":
    run_tests() if "--test" in sys.argv else print(__doc__)
