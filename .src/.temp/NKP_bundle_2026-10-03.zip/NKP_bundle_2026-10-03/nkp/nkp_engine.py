"""
NKP v2: New Knowledge Pattern, grounded.

Core loop (per item):
  1. PREDICT   - a learned model scores how surprising the item is (bits per token).
  2. COMPARE   - surprisal is compared to an adaptive horizon (recent mean + k*std).
  3. ROUTE     - above horizon -> EXPAND (allocate attention); else COMPRESS (known).
  4. LEARN     - the model absorbs the item, so what was unknown becomes known.
  5. ADAPT     - the horizon updates from observed surprisal (habituation).

Differences from v1: "known/unknown" is measured by prediction error, not by a
constant (118) compared to slot*digit*13; value is excess surprisal in bits, not
log(state-118)*digit; and the loop feeds back, so repeats compress.

Standard library only.  Run:  python nkp_engine.py          (demo + SVG)
                              python nkp_engine.py --test   (self-tests)
"""
from __future__ import annotations

import math
import re
import sys
from collections import Counter, defaultdict
from dataclasses import dataclass
from typing import Iterable, List, Optional

TOKEN_RE = re.compile(r"[a-z0-9']+")


def tokenize(text: str) -> List[str]:
    return ["<s>"] + TOKEN_RE.findall(text.lower())


# --------------------------------------------------------------------------
# 1. Predictive model: interpolated bigram/unigram (Witten-Bell style)
# --------------------------------------------------------------------------
class PredictiveModel:
    """Scores items by mean surprisal (bits/token) and learns from them."""

    def __init__(self, alpha: float = 0.5, open_vocab: int = 2000):
        self.alpha = alpha
        self.open_vocab = open_vocab  # prior guess at vocabulary size (unseen mass)
        self.uni: Counter = Counter()
        self.follow: defaultdict = defaultdict(Counter)
        self.total = 0

    def _p(self, prev: str, tok: str) -> float:
        v = len(self.uni)
        p_uni = (self.uni[tok] + self.alpha) / (self.total + self.alpha * (v + self.open_vocab))
        ctx = self.follow.get(prev)
        if not ctx:
            return p_uni
        c = sum(ctx.values())
        lam = c / (c + len(ctx))
        return lam * ctx[tok] / c + (1 - lam) * p_uni

    def surprisal(self, text: str):
        """Return (mean bits per token, count of never-seen tokens)."""
        toks = tokenize(text)
        bits, unseen = [], 0
        for prev, tok in zip(toks, toks[1:]):
            if self.uni[tok] == 0:
                unseen += 1
            bits.append(-math.log2(self._p(prev, tok)))
        return (sum(bits) / len(bits), unseen) if bits else (0.0, 0)

    def learn(self, text: str) -> None:
        toks = tokenize(text)
        for prev, tok in zip(toks, toks[1:]):
            self.uni[tok] += 1
            self.total += 1
            self.follow[prev][tok] += 1


# --------------------------------------------------------------------------
# 2. Adaptive horizon: exponential moving mean/variance of surprisal
# --------------------------------------------------------------------------
class AdaptiveHorizon:
    def __init__(self, k: float = 1.5, ema: float = 0.15, min_std: float = 0.75):
        self.k, self.ema, self.min_std = k, ema, min_std
        self.mean, self.var, self.n = 0.0, 0.0, 0

    def value(self) -> Optional[float]:
        if self.n == 0:
            return None
        return self.mean + self.k * max(math.sqrt(self.var), self.min_std)

    def update(self, x: float) -> None:
        if self.n == 0:
            self.mean = x
        else:
            d = x - self.mean
            self.mean += self.ema * d
            self.var = (1 - self.ema) * (self.var + self.ema * d * d)
        self.n += 1


# --------------------------------------------------------------------------
# 3. Engine
# --------------------------------------------------------------------------
@dataclass
class Node:
    slot: int
    text: str
    surprisal: float      # bits/token before learning this item
    unseen: int           # tokens never seen before
    horizon: Optional[float]
    excess: float         # bits above horizon (0 unless EXPAND)
    status: str           # WARMUP | COMPRESS | EXPAND


class NKPEngine:
    def __init__(self, warmup: int = 5, model: Optional[PredictiveModel] = None,
                 horizon: Optional[AdaptiveHorizon] = None):
        self.warmup = warmup
        self.model = model or PredictiveModel()
        self.horizon = horizon or AdaptiveHorizon()
        self.log: List[Node] = []

    def process(self, text: str) -> Node:
        s, unseen = self.model.surprisal(text)
        h = self.horizon.value()
        in_warmup = len(self.log) < self.warmup
        if in_warmup or h is None:
            status, excess = "WARMUP", 0.0
        elif s > h:
            status, excess = "EXPAND", s - h
        else:
            status, excess = "COMPRESS", 0.0
        node = Node(len(self.log) + 1, text, s, unseen, None if in_warmup else h, excess, status)
        self.model.learn(text)      # known-ness is earned, not assumed
        if not in_warmup:
            self.horizon.update(s)  # horizon tracks what is now normal
        self.log.append(node)
        if in_warmup and len(self.log) == self.warmup:
            self._seed_horizon()
        return node

    def _seed_horizon(self) -> None:
        """Cold-start surprisal (empty model) is not 'normal'. Seed the horizon by
        re-scoring the warm-up items under the model they just trained."""
        for nd in self.log:
            self.horizon.update(self.model.surprisal(nd.text)[0])

    def run(self, items: Iterable[str]) -> List[Node]:
        return [self.process(t) for t in items]


# --------------------------------------------------------------------------
# 4. Renderer: circular ribbon, driven by engine output
# --------------------------------------------------------------------------
def render_svg(nodes: List[Node], path: str = "nkp_ribbon.svg") -> None:
    W = H = 1000
    cx = cy = 500
    r_in, r_out = 250, 380
    r_mid = (r_in + r_out) / 2
    n = len(nodes)
    seg = 2 * math.pi / n
    max_excess = max([nd.excess for nd in nodes] + [1e-9])
    out = [
        f'<svg width="{W}" height="{H}" viewBox="0 0 {W} {H}" xmlns="http://www.w3.org/2000/svg">',
        '<rect width="100%" height="100%" fill="#0a0a0c"/>',
        f'<circle cx="{cx}" cy="{cy}" r="{r_in}" fill="none" stroke="#222530" stroke-width="1.5"/>',
        f'<circle cx="{cx}" cy="{cy}" r="{r_out}" fill="none" stroke="#222530" stroke-width="1.5"/>',
    ]

    def pt(r, a):
        return cx + r * math.cos(a), cy + r * math.sin(a)

    for i, nd in enumerate(nodes):
        a0, a1 = i * seg - math.pi / 2, (i + 1) * seg - math.pi / 2
        am = (a0 + a1) / 2
        x1, y1 = pt(r_in, a0)
        x2, y2 = pt(r_out, a0)
        out.append(f'<line x1="{x1:.1f}" y1="{y1:.1f}" x2="{x2:.1f}" y2="{y2:.1f}" stroke="#3a3f54" stroke-width="1"/>')
        tx, ty = pt(r_out + 26, am)
        deg = math.degrees(am) % 360
        rot = deg + 180 if 90 < deg < 270 else deg
        out.append(f'<text x="{tx:.1f}" y="{ty:.1f}" transform="rotate({rot:.1f},{tx:.1f},{ty:.1f})" '
                   f'fill="#6c7393" font-family="monospace" font-size="11" text-anchor="middle">'
                   f'{nd.slot:02d}·{nd.surprisal:.1f}b</text>')
        if nd.status == "COMPRESS":       # known: dense, flat bars
            for b in range(10):
                ba = a0 + (b / 10) * seg
                bx1, by1 = pt(r_in, ba)
                bx2, by2 = pt(r_out, ba)
                out.append(f'<line x1="{bx1:.1f}" y1="{by1:.1f}" x2="{bx2:.1f}" y2="{by2:.1f}" stroke="#2a2d3d" stroke-width="0.75"/>')
        elif nd.status == "WARMUP":       # no baseline yet: faint dashed arc
            pts = " ".join("%.1f,%.1f" % pt(r_mid, a0 + (s / 12) * seg) for s in range(13))
            out.append(f'<polyline points="{pts}" fill="none" stroke="#4a4f66" stroke-width="1.5" stroke-dasharray="3,5"/>')
        else:                             # EXPAND: amplitude proportional to excess bits
            amp = 60 * nd.excess / max_excess
            pts = " ".join(
                "%.1f,%.1f" % pt(r_mid + amp * math.sin(t / 30 * math.pi * 3), a0 + (t / 30) * seg)
                for t in range(31))
            out.append(f'<polyline points="{pts}" fill="none" stroke="#a370f7" stroke-width="2" stroke-linecap="round"/>')
            gx, gy = pt(r_mid, am)
            out.append(f'<circle cx="{gx:.1f}" cy="{gy:.1f}" r="3" fill="#ff79c6"/>')

    exp = sum(nd.status == "EXPAND" for nd in nodes)
    out.append(f'<text x="{cx}" y="{cy}" fill="#8a90ad" font-family="monospace" font-size="16" '
               f'text-anchor="middle">{n} items · {exp} expanded</text>')
    out.append("</svg>")
    with open(path, "w") as f:
        f.write("\n".join(out))


# --------------------------------------------------------------------------
# 5. Demo stream + self-tests
# --------------------------------------------------------------------------
ANOMALY = "unexpected quantum flux detected in cooling loop seven"
DEMO = [
    "backup completed successfully for volume alpha",
    "backup completed successfully for volume beta",
    "backup completed successfully for volume gamma",
    "user login accepted from office network",
    "user login accepted from home network",
    "backup completed successfully for volume alpha",
    "user login accepted from office network",
    "backup completed successfully for volume beta",
    "user login accepted from home network",
    "backup completed successfully for volume gamma",
    "user login accepted from office network",
    "backup completed successfully for volume alpha",
    ANOMALY,                                                    # 13: novel
    "user login accepted from home network",
    "backup completed successfully for volume beta",
    "user login accepted from office network",
    ANOMALY,                                                    # 17: repeat
    "unexpected quantum flux detected in cooling loop eight",   # 18: variant
    "invoice paid by customer acme",                            # 19: regime shift
    "invoice paid by customer globex",
    "refund issued to customer acme",
    "invoice paid by customer initech",
    "refund issued to customer globex",
    "invoice paid by customer acme",
]


def report(nodes: List[Node]) -> None:
    print(f"{'#':>2} {'status':<9} {'bits':>5} {'horizon':>7} {'excess':>6} {'new':>3}  text")
    for n in nodes:
        h = "  -  " if n.horizon is None else f"{n.horizon:7.2f}"
        print(f"{n.slot:>2} {n.status:<9} {n.surprisal:5.2f} {h:>7} {n.excess:6.2f} {n.unseen:>3}  {n.text}")


def run_tests() -> None:
    # T1: habituation - a repeated item's surprisal must fall and end up known.
    e = NKPEngine()
    e.run(DEMO[:8])                              # routine baseline, past warm-up
    reps = [e.process("epsilon zeta eta theta") for _ in range(6)]
    s = [r.surprisal for r in reps]
    assert all(b < a for a, b in zip(s, s[1:])), f"surprisal should fall on repeats: {s}"
    assert reps[0].status == "EXPAND" and reps[-1].status == "COMPRESS", [r.status for r in reps]

    # T2: novelty spike - an out-of-pattern item after routine input is flagged.
    e = NKPEngine()
    nodes = e.run(DEMO[:12] + [ANOMALY])
    assert nodes[-1].status == "EXPAND", nodes[-1]
    routine_mean = sum(n.surprisal for n in nodes[5:12]) / 7
    assert nodes[-1].surprisal > 2 * routine_mean, (nodes[-1].surprisal, routine_mean)

    # T3: learning - the same anomaly seen again must be less surprising.
    e = NKPEngine()
    nodes = e.run(DEMO)
    assert nodes[16].surprisal < 0.5 * nodes[12].surprisal, (nodes[12].surprisal, nodes[16].surprisal)

    # T4: regime shift - new domain flagged first, absorbed by the end.
    assert nodes[18].status == "EXPAND" and nodes[-1].status == "COMPRESS", (nodes[18], nodes[-1])

    # T5: partial novelty - a variant costs less than the original but more than a repeat.
    assert nodes[16].surprisal < nodes[17].surprisal < nodes[12].surprisal

    # T6: determinism.
    a = [(n.status, round(n.surprisal, 9)) for n in NKPEngine().run(DEMO)]
    b = [(n.status, round(n.surprisal, 9)) for n in NKPEngine().run(DEMO)]
    assert a == b

    print("all 6 tests passed")


if __name__ == "__main__":
    if "--test" in sys.argv:
        run_tests()
    else:
        nodes = NKPEngine().run(DEMO)
        report(nodes)
        render_svg(nodes, "nkp_ribbon.svg")
        print("\nwrote nkp_ribbon.svg")
