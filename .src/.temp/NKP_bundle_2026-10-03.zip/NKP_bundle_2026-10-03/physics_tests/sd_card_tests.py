import numpy as np, math
print("=== A. 'Balanced gate' script (1-3_pi_phi_script), run exactly as written ===")
baseline, pi, phi = 1/3, np.pi, (1 + np.sqrt(5)) / 2
n = np.linspace(0, 10, 100)
gp = (np.sin(n * pi) * phi ** (n / 10)) / (pi * phi)
gate = np.abs(gp) > baseline
print(f"{'Step':<8} | {'Potential':<12} | Gate Status")
for i in range(0, 20, 2):
    print(f"n={n[i]:<6.1f} | {gp[i]:>10.4f} | {'OPEN (1)' if gate[i] else 'CLOSED (0)'}")
print(f"\nover ALL 100 steps: max |potential| = {np.abs(gp).max():.4f}   threshold 1/3 = {baseline:.4f}   times OPEN = {int(gate.sum())}")
print(f"analytic bound: |sin| <= 1 and phi^(n/10) <= phi  =>  |potential| <= 1/pi = {1/pi:.4f} < 1/3, because pi > 3. The gate can never open.")

print("\n=== B. TriEn v1 rebuild spec (Explanation.pdf) implemented with stated, generic parameters ===")
B = 100; SEC_K = np.array([0.1, 0.4, 0.8])          # kappa by sector (GASEOUS, LIQUID, SOLID); the spec leaves it undefined
PHI_C = (5 ** 0.5 - 1) / 2                          # the spec's phi-offset (golden ratio conjugate)
def sector(u): return 0 if u < 1/3 else (1 if u < 2/3 else 2)
def simulate(kind, steps=30000, rho=0.05, sigma=0.3, seed=0, kappa=SEC_K):
    rng = np.random.default_rng(seed); P = np.array([150, 200, 250])
    th0 = 2 * np.pi * ((np.arange(3) * PHI_C) % 1); I = np.zeros(B)
    slow = np.zeros(3); err_raw = [[], [], []]; err_cor = [[], [], []]
    for t in range(steps):
        for i in range(3):
            theta = (th0[i] + 2 * np.pi * t / P[i]) % (2 * np.pi); u = theta / (2 * np.pi); b = int(u * B) % B; s = sector(u)
            if kind == "periodic":   clean = np.sin(theta) + 0.2 * np.sin(2 * theta)
            elif kind == "drifting": clean = (1 + 0.5 * t / steps) * np.sin(theta) + 0.2 * np.sin(2 * theta)
            else:                    slow[i] = 0.995 * slow[i] + 0.1 * rng.normal(); clean = slow[i]          # non-repeating signal
            w = clean + sigma * rng.normal()
            R = I[b]; C = w - R; corr = w - kappa[s] * C; I[b] = (1 - rho) * I[b] + rho * corr
            if t > steps - 6000: err_raw[s].append(w - clean); err_cor[s].append(corr - clean)
    rms = lambda a: float(np.sqrt(np.mean(np.square(a))))
    return [rms(err_raw[s]) for s in range(3)], [rms(err_cor[s]) for s in range(3)], rms(sum(err_raw, [])), rms(sum(err_cor, []))
for kind, label in (("periodic", "repeating signal + noise (sigma=0.3)"), ("drifting", "same, but amplitude drifts +50% over the run"), ("nonperiodic", "NON-repeating signal + noise")):
    rr, cc, ra, ca = simulate(kind)
    print(f"{label}\n   RMS error vs clean signal: raw {ra:.3f} -> corrected {ca:.3f}   by sector (gas/liquid/solid): raw {rr[0]:.2f}/{rr[1]:.2f}/{rr[2]:.2f} -> {cc[0]:.2f}/{cc[1]:.2f}/{cc[2]:.2f}")
print("note: W_corrected = (1-kappa)*W + kappa*R, i.e. each sample is blended with a running average of what this loop position looked like before.")

print("\n=== C. Numbers from the screenshots ===")
phi_c = (1 + 5 ** 0.5) / 2
print(f"continued fraction 1+1/(1+1/(1+...)) = phi = {phi_c:.10f};  2cos(pi/5) = {2*math.cos(math.pi/5):.10f}  (Gemini's identity is correct)")
def legal_positions():
    seen, stack = set(), [(0,) * 9]
    lines = [(0,1,2),(3,4,5),(6,7,8),(0,3,6),(1,4,7),(2,5,8),(0,4,8),(2,4,6)]
    def won(b, p): return any(all(b[i] == p for i in l) for l in lines)
    while stack:
        b = stack.pop()
        if b in seen: continue
        seen.add(b)
        if won(b, 1) or won(b, 2) or 0 not in b: continue
        p = 1 if b.count(1) == b.count(2) else 2
        for i in range(9):
            if b[i] == 0: stack.append(b[:i] + (p,) + b[i+1:])
    return len(seen)
print(f"tic-tac-toe: 3^9 = {3**9} boards is the count of ALL fillings; positions actually reachable in play = {legal_positions()}")
ga = 360 * (1 - 1 / phi_c); inv_alpha = 137.035999084
print(f"golden angle = {ga:.6f} deg;  1/alpha (fine-structure) = {inv_alpha:.6f};  difference {ga-inv_alpha:.4f} = {abs(ga-inv_alpha)/inv_alpha:.2e} relative")
print("alpha is measured to about 1e-10 relative, so a 3e-3 gap is ~7 orders of magnitude outside; and 'degrees' is an arbitrary unit while 1/alpha is dimensionless")
