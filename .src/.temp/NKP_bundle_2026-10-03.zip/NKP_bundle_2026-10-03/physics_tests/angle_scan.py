import numpy as np
N = 300
n = np.arange(1, N + 1)
r = np.sqrt(n)
def metrics(alpha_deg):
    th = np.deg2rad(alpha_deg) * n
    x, y = r * np.cos(th), r * np.sin(th)
    d = np.hypot(x[:, None] - x[None, :], y[:, None] - y[None, :]); np.fill_diagonal(d, np.inf)
    nn = d.min(axis=1)
    return nn.min(), nn.std() / nn.mean()          # min spacing (bigger better), spread of spacing (smaller better)
angles = np.arange(90.0, 180.0001, 0.05)
res = np.array([metrics(a) for a in angles])
golden = 360 * (1 - 2 / (1 + 5 ** 0.5))
g_min, g_cv = metrics(golden)
print(f"golden angle = {golden:.4f} deg   min-spacing {g_min:.3f}   spacing-CV {g_cv:.3f}")
for a in (137.5, 137.3, 137.7, 137.0, 138.0, 135.0, 140.0, 120.0):
    m, c = metrics(a); print(f"  {a:>6.1f} deg   min-spacing {m:.3f} ({m/g_min:5.0%} of golden)   CV {c:.3f}")
order = np.argsort(-res[:, 0])
print("\ntop 8 scanned angles by min-spacing (deg, min-spacing):")
seen = []
for i in order:
    if all(abs(angles[i] - s) > 0.5 for s in seen):
        seen.append(angles[i]); print(f"  {angles[i]:.2f}  {res[i,0]:.3f}")
    if len(seen) == 8: break
rank_min = int((res[:, 0] > g_min + 1e-9).sum()) + 1
rank_cv = int((res[:, 1] < g_cv - 1e-9).sum()) + 1
print(f"\nrank of golden angle among {len(angles)} scanned angles: by min-spacing #{rank_min}, by spacing-CV #{rank_cv}")
print(f"angles within 5% of the best min-spacing: {int((res[:,0] >= 0.95*res[:,0].max()).sum())} of {len(angles)}")
