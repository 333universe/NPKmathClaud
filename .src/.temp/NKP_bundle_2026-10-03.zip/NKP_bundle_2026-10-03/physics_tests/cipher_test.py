# Cipher code transcribed from the uploaded document (indentation reconstructed; cipher_idx += 1 placed at the
# outer-loop level, the only placement that doesn't raise IndexError).
import numpy as np, hashlib
PHI = (1 + 5**0.5) / 2
C_FACTOR = 1 / 3
def generate_deterministic_salt(secret_key, index):
    h = hashlib.sha256(f"{secret_key}-{index}".encode()).hexdigest()
    return int(h[:12], 16) / (16**12)
def skew_tent_map(x, omega=0.4):
    x = np.clip(x, 1e-10, 1.0 - 1e-10)
    if x < omega:
        return x / omega
    else:
        return (1 - x) / (1 - omega)
def secure_uase_encrypt(plaintext_vector, secret_key):
    data = np.array(plaintext_vector, dtype=float)
    remainder = len(data) % 3
    if remainder != 0:
        data = np.pad(data, (0, 3 - remainder), 'constant')
    ciphertext, salts_used = [], []
    for i in range(0, len(data), 3):
        block = data[i:i+3]; salted_block = []
        for idx, val in enumerate(block):
            gi = i + idx
            salt = generate_deterministic_salt(secret_key, gi); salts_used.append(salt)
            salted_block.append(np.sin(val * (PHI + salt)) * (gi + 1))
        ciphertext.append(C_FACTOR * sum(salted_block))
    delta_e = skew_tent_map(np.abs(np.sin(np.mean(ciphertext))))
    return np.array(ciphertext), delta_e, len(plaintext_vector), salts_used
def secure_uase_decrypt(ciphertext, delta_e, original_length, secret_key, salts_used):
    rec, ci = [], 0
    for i in range(0, original_length, 3):
        block_sum = ciphertext[ci] / C_FACTOR
        for idx in range(3):
            gi = i + idx
            if gi >= original_length: break
            dphi = PHI + salts_used[gi]
            u = np.clip((block_sum / 3.0) / (gi + 1), -1.0, 1.0)
            rec.append(np.arcsin(u) / dphi)
        ci += 1
    return np.array(rec[:original_length])

pt = [42.0, 108.5, 256.12, 19.8, 88.0, 14.3]
ct, de, n, salts = secure_uase_encrypt(pt, "SuperSecretManifoldKey2026")
print("plaintext           :", pt)
print("ciphertext (2 values for 6 inputs):", np.round(ct, 4).tolist())
print("recovered (right key):", np.round(secure_uase_decrypt(ct, de, n, "SuperSecretManifoldKey2026", salts), 3).tolist())
print("recovered (WRONG key):", np.round(secure_uase_decrypt(ct, de, n, "totally-wrong-key", salts), 3).tolist())
# does the code still contain a data-dependent branch?
import inspect
print("branch in 'constant-time' map:", "if x < omega" in inspect.getsource(skew_tent_map))
# non-injectivity: different plaintexts, identical output
a = secure_uase_encrypt([1.0, 2.0, 3.0], "k")[0]; b = secure_uase_encrypt([1.0, 2.0, 3.0], "k")[0]
c = secure_uase_encrypt([2.0, 1.0, 3.0], "k")[0]
print("distinct 3-value plaintexts, ciphertext 1 number each:", np.round(a,4).tolist(), np.round(c,4).tolist())
