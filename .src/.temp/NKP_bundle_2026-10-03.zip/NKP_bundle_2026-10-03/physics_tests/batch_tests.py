import numpy as np, math
from fractions import Fraction
phi = (1 + 5 ** 0.5) / 2
GA = 2 * math.pi / phi ** 2

print("=== 1. The pi-phi-1/3 'sieve' from the PDF: S(n) = floor(n * 2*pi/phi^2) mod 3 ===")
print(f"golden angle 2*pi/phi^2 = {GA:.7f} rad = {math.degrees(GA):.4f} deg  (matches the document)")
n12 = np.arange(1, 13, dtype=np.float32)
route = (np.floor(n12 * np.float32(GA)).astype(np.int64)) % 3          # exactly the layer's code path (float32)
print("12-token demo routing :", route.tolist())
print("kept (channel 0) mask :", (route == 0).astype(int).tolist(), f"-> {int((route==0).sum())} of 12 kept")
print("code returns x[:, keep_mask]  => tokens in channels 1 AND 2 are both dropped, not just 'a third'")
for N in (12, 100, 1000, 10000, 27000, 100000, 1000000):
    n = np.arange(1, N + 1, dtype=np.float64); s = np.floor(n * GA).astype(np.int64) % 3
    c = np.bincount(s, minlength=3) / N
    lag5 = float((s[:-5] == s[5:]).mean())
    print(f"  N={N:>8}: channel shares 0/1/2 = {c[0]:.3f}/{c[1]:.3f}/{c[2]:.3f}   P[s(n)=s(n+5)] = {lag5:.3f}")
print("  (a truly aperiodic, 'no periodic bias' router would show 0.333 each and ~0.333 at lag 5)")
print("  first 20 routes:", (np.floor(np.arange(1, 21) * GA).astype(int) % 3).tolist())
print("  the multiplier is 2.39996 ~ 12/5: alpha/3 = %.5f ~ 4/5, a near-rational => near-period 5" % (GA / 3))

print("\n=== 2. Copilot 'fundamental process entity': phi_{n+1} = lam(1+1/phi_n) + (1-lam)*2cos(pi/5 + w n) ===")
print(f"identity check: 2cos(pi/5) = {2*math.cos(math.pi/5):.12f}   phi = {phi:.12f}   diff = {2*math.cos(math.pi/5)-phi:.2e}  (true identity)")
def run(lam, w, N=4000, p0=1.0):
    p, out = p0, []
    for k in range(N):
        p = lam * (1 + 1 / p) + (1 - lam) * 2 * math.cos(math.pi / 5 + w * k); out.append(p)
        if abs(p) > 1e9: return out, True
    return out, False
print(f"{'lambda':>7}{'omega':>9}   {'behaviour of phi_n (last 2000 iterates)':<60}")
for lam in (1.0, 0.5, 0.0):
    for w in (0.0, 0.5, GA):
        o, blown = run(lam, w)
        a = np.array(o[-2000:]) if not blown else np.array(o)
        near0 = float((np.abs(a) < 0.05).mean())
        desc = "BLOW-UP (1/phi_n singular)" if blown else f"range [{a.min():.3f}, {a.max():.3f}], mean {a.mean():.3f}, {near0:.1%} of steps within 0.05 of zero"
        if lam == 1.0: desc += f"   (converges to {a[-1]:.6f})"
        print(f"{lam:>7}{w:>9.4f}   {desc}")

print("\n=== 3. Copilot 'single equation': P = (I*sqrt(X))^(1+b s) * T / sqrt(X), X = -T_ab u^a u^b ===")
eta = np.diag([-1., 1., 1., 1.]); rho = 1.0
u_up = np.array([1., 0, 0, 0]); u_dn = eta @ u_up
T = rho * np.outer(u_dn, u_dn)                                  # dust at rest, T_ab = rho u_a u_b
X = -(u_up @ T @ u_up)
print(f"dust, rho = {rho}: T_ab u^a u^b = {u_up @ T @ u_up:+.2f}  =>  X = -T u u = {X:+.2f}   (sqrt of negative => P is complex for ordinary matter)")
I, bs = 1.3, 0.25; Xp = abs(X)
lhs = (I * Xp ** 0.5) ** (1 + bs) / Xp ** 0.5
rhs = I ** (1 + bs) * Xp ** (bs / 2)
print(f"algebra (taking |X|): P/T = {lhs:.10f}  vs  I^(1+bs) * X^(bs/2) = {rhs:.10f}  -> the whole 'machinery' is a scalar factor f(rho) on T_ab")
print("with b*s = 0 it is exactly I * T_ab, i.e. GR with G -> I*G; b and s are never defined.")
print("conservation: Bianchi needs div(f T) = 0, but div(f T) = f div(T) + T.grad f; for dust T_ab grad^a f = rho u_b (df/dtau) != 0 whenever rho changes along the flow")

print("\n=== 4. 'Triadic Flaw': 1 = 3 x 0.3333... + 0.0001, F_n = 10^-n ===")
for k in (1, 2, 4, 8, 12):
    P = Fraction(10 ** k - 1, 3 * 10 ** k)
    print(f"  n={k:>2}: 3*P_n = {float(3*P):.12f}   1 - 3*P_n = {float(1-3*P):.1e}   equals 10^-n exactly: {1-3*P == Fraction(1, 10**k)}")
print("  with infinitely many 3s (the '...') the remainder is exactly 0, so 3 x 0.333... + 0.0001 = 1.0001, not 1")
print("  the 'flaw' is the truncation error of writing 1/3 in base 10; in base 3, 1/3 = 0.1 and the flaw is 0")
